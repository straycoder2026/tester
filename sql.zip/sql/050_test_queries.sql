/* Safe inspection and audit-only test controls. */

/* 1. Confirm safe defaults. */
SELECT * FROM xt.ConfigInstance;
SELECT * FROM xt.ConfigTermination;
SELECT * FROM xt.CommandProfile ORDER BY ProfileId;
GO

/* 2. Enable collection in AUDIT-ONLY mode. This cannot dispatch termination. */
UPDATE xt.ConfigTermination
SET Enabled = 1,
    OperatingMode = 'AuditOnly',
    UpdatedUtc = SYSUTCDATETIME(),
    UpdatedBy = ORIGINAL_LOGIN()
WHERE ConfigId = 1;
GO

/* 3. Run a manual monitoring cycle. */
EXEC xt.usp_MonitorCycle;
GO

/* 4. Inspect observations and proposed actions. */
SELECT TOP (200) * FROM xt.BlockingObservation ORDER BY ObservationId DESC;
SELECT TOP (100) * FROM xt.vw_TerminationDashboard ORDER BY CandidateId DESC;
SELECT TOP (200) * FROM xt.TerminationRuleEvaluation ORDER BY EvaluationId DESC;
GO

/* 5. Return to disabled after the test if desired. */
-- UPDATE xt.ConfigTermination SET Enabled = 0, OperatingMode = 'Disabled',
--     UpdatedUtc = SYSUTCDATETIME(), UpdatedBy = ORIGINAL_LOGIN()
-- WHERE ConfigId = 1;
GO

/*
  Automatic mode is intentionally not enabled by this script. Before a controlled
  automatic test, configure termination-settings.json with enabled=true while
  leaving simulationOnly=true. Then explicitly set OperatingMode='Automatic'.
  The first automatic test should produce ActionStatus='Simulated'.
*/

