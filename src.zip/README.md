# SQL Analyzer – Visual Studio 2022 / .NET Framework 4.8

SQL Analyzer reviews SQL Server estimated or actual execution plans and optionally the corresponding stored procedure.

## Main features

### Single analysis
- Loads `.sqlplan` estimated or actual plans.
- Accepts a stored procedure as an optional `.sql` file.
- Maps statements to source lines where possible.
- Reports where the issue is, time/cost impact, why it happened, the fix, immediate-vs-future priority, and supporting evidence.

### Before / after comparison
Creates three separate reports:
1. `01_Before_Detailed_Report.html`
2. `02_After_Detailed_Report.html`
3. `03_Comparison_Executive_Report.html`

The comparison report lists what improved, what became worse, new issues, resolved issues, and an executive release recommendation.

## Build and run
1. Extract to `C:\Projects\SqlAnalyzer`.
2. Open `SqlAnalyzer.sln` in Visual Studio 2022.
3. Install `.NET desktop development` and the .NET Framework 4.8 Developer Pack if prompted.
4. Set `SqlAnalyzer.Desktop` as the startup project.
5. Build and press F5.

No App.config is included.

## Accuracy
- Actual time is available only in actual plans containing runtime counters.
- Estimated plans show estimated cost contribution, not invented elapsed time.
- Operator timings can overlap because operators execute as pipelines.
- Recommendations require developer and DBA validation against the full workload.

## Executive report filtering update

The executive section now shows only Critical, High, and Fix-Now findings. Medium,
Low, informational findings, and all execution-plan operators remain in the detailed
Developer and DBA sections.

A new **Fix Location** column identifies the procedure line, plan statement, node,
object, index, predicate, join, sort, or memory-grant area where remediation should begin.
The before/after executive comparison uses the same filtering and keeps the full detail
in separate technical tables.


## Statement-grouped reporting

Version 3 groups all execution-plan findings by `StatementId`.

- The executive table shows one row per SQL statement.
- All issues caused by that statement are listed together.
- Node IDs remain visible only inside the grouped issue list and DBA appendix.
- Statement-level elapsed time, CPU, reads, procedure line and SQL text are shown once.
- Comparison reports group new and resolved issues by statement to reduce node-level confusion.


## Statement resource ranking

Version 4 adds statement-level resource ranking.

- Identifies the statement consuming the most elapsed time.
- Identifies the statement consuming the most CPU.
- Identifies the statement performing the most logical reads.
- Ranks estimated plans by optimizer cost when runtime metrics are unavailable.
- Shows each statement's percentage of total captured statement resources.
- Adds before/after resource-leadership comparison.


## Statement execution and duplicate-node consolidation

Version 5 improves statement-level reporting:

- Reads statement execution count from the root execution-plan operator.
- Uses `QueryTimeStats` for statement elapsed and CPU time, with root-runtime fallback.
- Displays long durations in seconds and milliseconds, for example:
  `58.00 sec (58,000 ms)`.
- Consolidates identical issues repeated across plan nodes.
- Reports how many times each issue was detected and lists affected node IDs.
- Keeps node-by-node evidence only in the DBA technical table.


## Plan-validated runtime parsing (Version 6)

Version 6 was adjusted against the patient-profile actual execution plan.

Key corrections:

- Reads statement duration from `StmtSimple/QueryPlan/QueryTimeStats`.
- Reads each RelOp's own runtime counters only; child-node counters are no longer incorrectly inherited by parent nodes.
- Calculates logical reads from storage access operators rather than summing every plan node.
- Captures scalar UDF names from `UserDefinedFunction`.
- Detects a dominant runtime operator/function when it consumes at least 50% of statement time.
- Reports statement duration separately from the dominant function/operator duration.
- Consolidates root cause, fix location and remediation into one statement-level plan.

For the reference plan, the expected evidence is:

- Statement 6: approximately 65.664 seconds elapsed for one captured execution.
- `dbo.f_GetPrevRxComplete`: approximately 58.961 seconds and 30,353 executions.
- Function lookup logical reads: approximately 86,290.
- The report should identify early repeated function evaluation before row reduction as the main root cause.


## Version 7 timing correction

The uploaded patient-profile plan stores these actual Statement 6 values in
`QueryTimeStats`:

- ElapsedTime: 1121 ms
- CpuTime: 750 ms
- UdfElapsedTime: 621 ms
- UdfCpuTime: 621 ms

The analyzer now displays those values explicitly with their XML source.
It does not replace them with a runtime observed outside the uploaded plan.

Version 7 also:

- removes parent-node runtime inheritance;
- reports memory-grant issues once per statement;
- limits cardinality findings to likely root access/join points;
- consolidates fix location at statement level;
- adds a captured-timing source-of-truth table.


## Version 8 diagnostic comparison

The comparison report now explains why performance changed:

- identifies the primary slow statement independently in each plan;
- compares elapsed, CPU, UDF elapsed and UDF CPU;
- calculates UDF percentage of statement duration;
- states whether scalar UDF processing caused the slowdown;
- lists improvements, regressions, new issues and resolved issues;
- provides a consolidated remediation starting point.

The report uses timing stored in each uploaded actual plan and does not assume
that statement IDs remain the same between captures.


## Version 9 exact SQL-fragment mapping

Version 9 maps execution-plan findings back to the smallest reliable SQL fragment:

- filtering problems show the exact `WHERE` clause and line range;
- join problems show the relevant `JOIN ... ON` clause;
- sort/spill problems show `ORDER BY` or `GROUP BY`;
- correlated and lookup subqueries display their complete nested SQL text;
- scalar UDF findings display the exact function call and function name;
- query-wide problems display the full parent statement.

The report never assigns the complete statement duration to every fragment.
Fragment timing is shown only when SQL Server exposes it; otherwise the report
states that timing belongs to the parent statement.


## Version 10 component-level diagnosis

Version 10 fixes the main reporting gap found in the generated 65-second report.

The report now explicitly identifies:

- the parent slow statement;
- every UDF name found in statement text or plan function metadata;
- the exact UDF call expression;
- aggregate statement UDF elapsed/CPU time;
- per-function executions and logical reads when exposed by the plan;
- filtering SQL and rows-read-versus-returned evidence;
- join clauses with cardinality mismatch;
- repeated lookup objects and execution counts;
- sort/spill evidence without incorrectly treating root Sort pipeline time
  as independent sort time.

Important accuracy rule:

`QueryTimeStats.UdfElapsedTime` is aggregate statement UDF time. It is not
assigned to one UDF unless the plan provides independently attributable timing.
The report can still strongly implicate a named UDF using its execution count,
logical reads and related operator evidence.


## Version 11 — SQL Server connected mode

A third application tab, **SQL Server Connected**, is now available.

Connected mode:
- loads an uploaded `.sqlplan`;
- connects using Windows Authentication or SQL Authentication;
- reads `ParentObjectId` from the plan;
- retrieves the matching stored procedure/module from `sys.sql_modules`;
- automatically uses that source for line mapping, filtering/subquery/UDF
  detection and component diagnosis;
- retrieves source definitions for referenced scalar UDFs;
- retrieves current index definitions for referenced tables;
- adds the retrieved source and metadata to the HTML report.

The execution plan remains the source of truth for captured elapsed time, CPU,
actual rows, executions, reads, waits, memory and spills. The live database is
used for source and current metadata. No data modifications are performed.
