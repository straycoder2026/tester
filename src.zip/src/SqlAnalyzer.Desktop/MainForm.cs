using System;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;
using SqlAnalyzer.Analysis;
using SqlAnalyzer.Core;
using SqlAnalyzer.Reporting;

namespace SqlAnalyzer.Desktop
{
    public sealed class MainForm : Form
    {
        private readonly TextBox _plan = NewTextBox();
        private readonly TextBox _procedure = NewTextBox();
        private readonly TextBox _beforePlan = NewTextBox();
        private readonly TextBox _beforeProcedure = NewTextBox();
        private readonly TextBox _afterPlan = NewTextBox();
        private readonly TextBox _afterProcedure = NewTextBox();
        private readonly TextBox _output = NewTextBox();
        private readonly TextBox _connectedPlan = NewTextBox();
        private readonly TextBox _connectedServer = NewTextBox();
        private readonly TextBox _connectedDatabase = NewTextBox();
        private readonly TextBox _connectedUser = NewTextBox();
        private readonly TextBox _connectedPassword = NewTextBox();
        private readonly TextBox _connectedOutput = NewTextBox();
        private readonly CheckBox _integratedSecurity = new CheckBox
        {
            Text = "Windows Authentication",
            Checked = true,
            AutoSize = true
        };

        public MainForm()
        {
            Text = "SQL Analyzer";
            Width = 1000;
            Height = 680;
            StartPosition = FormStartPosition.CenterScreen;

            var tabs = new TabControl { Dock = DockStyle.Fill };
            tabs.TabPages.Add(BuildAnalyzeTab());
            tabs.TabPages.Add(BuildCompareTab());
            tabs.TabPages.Add(BuildConnectedTab());
            Controls.Add(tabs);
        }

        private TabPage BuildAnalyzeTab()
        {
            var page = new TabPage("Analyze Plan / Procedure");
            var panel = NewPanel();

            AddFileRow(panel, 20, "Execution plan (.sqlplan):", _plan,
                () => Browse(_plan, "SQL execution plan|*.sqlplan|XML file|*.xml"));
            AddFileRow(panel, 75, "Stored procedure (.sql, optional):", _procedure,
                () => Browse(_procedure, "SQL source|*.sql|Text file|*.txt"));
            AddFileRow(panel, 130, "Output report (.html):", _output,
                () => Save(_output, "HTML report|*.html"));

            panel.Controls.Add(new Label
            {
                Left = 20,
                Top = 190,
                Width = 880,
                Height = 70,
                Text = "Plan-only analysis is supported. Add the stored procedure to enable " +
                       "source-line mapping and static SQL checks. Actual time is available " +
                       "only from an actual execution plan."
            });

            var button = new Button
            {
                Left = 20,
                Top = 275,
                Width = 190,
                Height = 38,
                Text = "Generate Analysis Report"
            };
            button.Click += AnalyzeClick;
            panel.Controls.Add(button);

            page.Controls.Add(panel);
            return page;
        }

        private TabPage BuildCompareTab()
        {
            var page = new TabPage("Compare Before / After");
            var panel = NewPanel();

            AddFileRow(panel, 20, "Before plan:", _beforePlan,
                () => Browse(_beforePlan, "SQL execution plan|*.sqlplan|XML file|*.xml"));
            AddFileRow(panel, 75, "Before procedure (optional):", _beforeProcedure,
                () => Browse(_beforeProcedure, "SQL source|*.sql|Text file|*.txt"));
            AddFileRow(panel, 130, "After plan:", _afterPlan,
                () => Browse(_afterPlan, "SQL execution plan|*.sqlplan|XML file|*.xml"));
            AddFileRow(panel, 185, "After procedure (optional):", _afterProcedure,
                () => Browse(_afterProcedure, "SQL source|*.sql|Text file|*.txt"));

            var button = new Button
            {
                Left = 20,
                Top = 255,
                Width = 225,
                Height = 38,
                Text = "Generate Diagnostic Comparison"
            };
            button.Click += CompareClick;
            panel.Controls.Add(button);

            panel.Controls.Add(new Label
            {
                Left = 20,
                Top = 315,
                Width = 880,
                Height = 100,
                Text = "The tool creates separate Before Detailed, After Detailed, and " +
                       "Comparison reports. The comparison report lists improvements, " +
                       "regressions, new issues, resolved issues, and an executive summary."
            });

            page.Controls.Add(panel);
            return page;
        }


        private TabPage BuildConnectedTab()
        {
            var page = new TabPage("SQL Server Connected");
            var panel = NewPanel();

            AddFileRow(panel, 20, "Execution plan (.sqlplan):",
                _connectedPlan,
                () => Browse(_connectedPlan,
                    "SQL execution plan|*.sqlplan|XML file|*.xml"));

            AddTextRow(panel, 75, "SQL Server:", _connectedServer);
            AddTextRow(panel, 120, "Database:", _connectedDatabase);

            _integratedSecurity.Left = 230;
            _integratedSecurity.Top = 165;
            panel.Controls.Add(_integratedSecurity);

            AddTextRow(panel, 205, "SQL user:", _connectedUser);
            AddTextRow(panel, 250, "SQL password:", _connectedPassword);
            _connectedPassword.UseSystemPasswordChar = true;

            AddFileRow(panel, 305, "Output report (.html):",
                _connectedOutput,
                () => Save(_connectedOutput,
                    "HTML report|*.html"));

            var testButton = new Button
            {
                Left = 20,
                Top = 365,
                Width = 160,
                Height = 38,
                Text = "Test Connection"
            };
            testButton.Click += ConnectedTestClick;
            panel.Controls.Add(testButton);

            var analyzeButton = new Button
            {
                Left = 200,
                Top = 365,
                Width = 220,
                Height = 38,
                Text = "Analyze with SQL Server"
            };
            analyzeButton.Click += ConnectedAnalyzeClick;
            panel.Controls.Add(analyzeButton);

            panel.Controls.Add(new Label
            {
                Left = 20,
                Top = 425,
                Width = 900,
                Height = 120,
                Text =
                    "Connected mode uses the uploaded plan for runtime evidence " +
                    "and retrieves matching procedure/UDF source and current index " +
                    "metadata from SQL Server. Prefer the same database/version that " +
                    "created the plan, or a schema-identical restored copy."
            });

            page.Controls.Add(panel);
            return page;
        }

        private void ConnectedTestClick(object sender, EventArgs e)
        {
            try
            {
                new SqlServerMetadataService().TestConnection(
                    BuildConnectedProfile());

                MessageBox.Show(
                    "Connection successful.",
                    "SQL Analyzer",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    ex.Message,
                    "Connection failed",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void ConnectedAnalyzeClick(object sender, EventArgs e)
        {
            try
            {
                RequireFile(
                    _connectedPlan.Text,
                    "Select an execution plan.");

                if (string.IsNullOrWhiteSpace(
                    _connectedOutput.Text))
                {
                    _connectedOutput.Text = Path.Combine(
                        Path.GetDirectoryName(
                            _connectedPlan.Text),
                        Path.GetFileNameWithoutExtension(
                            _connectedPlan.Text) +
                        "_SQLConnected_Report.html");
                }

                var report =
                    new ConnectedAnalysisService().Analyze(
                        Path.GetFileNameWithoutExtension(
                            _connectedPlan.Text),
                        _connectedPlan.Text,
                        BuildConnectedProfile());

                new AnalysisReportWriter().Write(
                    report,
                    _connectedOutput.Text);

                OpenReport(_connectedOutput.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    ex.ToString(),
                    "SQL Analyzer",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private SqlServerConnectionProfile BuildConnectedProfile()
        {
            if (string.IsNullOrWhiteSpace(
                _connectedServer.Text))
            {
                throw new InvalidOperationException(
                    "Enter the SQL Server name.");
            }

            if (string.IsNullOrWhiteSpace(
                _connectedDatabase.Text))
            {
                throw new InvalidOperationException(
                    "Enter the database name.");
            }

            return new SqlServerConnectionProfile
            {
                ServerName = _connectedServer.Text.Trim(),
                DatabaseName = _connectedDatabase.Text.Trim(),
                IntegratedSecurity =
                    _integratedSecurity.Checked,
                UserName = _connectedUser.Text.Trim(),
                Password = _connectedPassword.Text,
                TrustServerCertificate = true
            };
        }

        private void AnalyzeClick(object sender, EventArgs e)
        {
            try
            {
                RequireFile(_plan.Text, "Select an execution plan.");

                if (string.IsNullOrWhiteSpace(_output.Text))
                {
                    _output.Text = Path.Combine(
                        Path.GetDirectoryName(_plan.Text),
                        Path.GetFileNameWithoutExtension(_plan.Text) +
                        "_SqlAnalyzer_Report.html");
                }

                var report = new AnalysisService().Analyze(
                    Path.GetFileNameWithoutExtension(_plan.Text),
                    _plan.Text,
                    EmptyToNull(_procedure.Text));

                new AnalysisReportWriter().Write(report, _output.Text);
                OpenReport(_output.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "SQL Analyzer",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CompareClick(object sender, EventArgs e)
        {
            try
            {
                RequireFile(_beforePlan.Text, "Select the before execution plan.");
                RequireFile(_afterPlan.Text, "Select the after execution plan.");

                using (var dialog = new FolderBrowserDialog())
                {
                    dialog.Description = "Select output folder for the three reports.";

                    if (dialog.ShowDialog(this) != DialogResult.OK)
                    {
                        return;
                    }

                    var service = new AnalysisService();
                    var before = service.Analyze(
                        "Before",
                        _beforePlan.Text,
                        EmptyToNull(_beforeProcedure.Text));
                    var after = service.Analyze(
                        "After",
                        _afterPlan.Text,
                        EmptyToNull(_afterProcedure.Text));

                    var beforeFile = Path.Combine(
                        dialog.SelectedPath,
                        "01_Before_Detailed_Report.html");
                    var afterFile = Path.Combine(
                        dialog.SelectedPath,
                        "02_After_Detailed_Report.html");
                    var comparisonFile = Path.Combine(
                        dialog.SelectedPath,
                        "03_Diagnostic_Comparison_Report.html");

                    var detailed = new AnalysisReportWriter();
                    detailed.Write(before, beforeFile);
                    detailed.Write(after, afterFile);

                    var comparison = new ComparisonService().Compare(before, after);
                    new ComparisonReportWriter().Write(comparison, comparisonFile);

                    OpenReport(comparisonFile);

                    var generatedFiles =
                        "Three reports were generated:" +
                        Environment.NewLine + Environment.NewLine +
                        beforeFile + Environment.NewLine +
                        afterFile + Environment.NewLine +
                        comparisonFile;

                    MessageBox.Show(generatedFiles, "SQL Analyzer",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "SQL Analyzer",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private static Panel NewPanel()
        {
            return new Panel { Dock = DockStyle.Fill, AutoScroll = true };
        }

        private static TextBox NewTextBox()
        {
            return new TextBox { Width = 650 };
        }

        private static void AddFileRow(
            Control parent,
            int top,
            string label,
            TextBox textBox,
            Action browse)
        {
            var lbl = new Label
            {
                Left = 20,
                Top = top + 4,
                Width = 205,
                Text = label
            };

            textBox.Left = 230;
            textBox.Top = top;

            var button = new Button
            {
                Left = 890,
                Top = top - 1,
                Width = 70,
                Height = 26,
                Text = "Browse"
            };
            button.Click += (sender, args) => browse();

            parent.Controls.Add(lbl);
            parent.Controls.Add(textBox);
            parent.Controls.Add(button);
        }


        private static void AddTextRow(
            Control parent,
            int top,
            string label,
            TextBox textBox)
        {
            var lbl = new Label
            {
                Left = 20,
                Top = top + 4,
                Width = 205,
                Text = label
            };

            textBox.Left = 230;
            textBox.Top = top;
            textBox.Width = 650;

            parent.Controls.Add(lbl);
            parent.Controls.Add(textBox);
        }

        private void Browse(TextBox target, string filter)
        {
            using (var dialog = new OpenFileDialog { Filter = filter })
            {
                if (dialog.ShowDialog(this) == DialogResult.OK)
                {
                    target.Text = dialog.FileName;
                }
            }
        }

        private void Save(TextBox target, string filter)
        {
            using (var dialog = new SaveFileDialog
            {
                Filter = filter,
                DefaultExt = "html"
            })
            {
                if (dialog.ShowDialog(this) == DialogResult.OK)
                {
                    target.Text = dialog.FileName;
                }
            }
        }

        private static string EmptyToNull(string value)
        {
            return string.IsNullOrWhiteSpace(value) ? null : value;
        }

        private static void RequireFile(string path, string message)
        {
            if (string.IsNullOrWhiteSpace(path) || !File.Exists(path))
            {
                throw new FileNotFoundException(message, path);
            }
        }

        private static void OpenReport(string path)
        {
            Process.Start(new ProcessStartInfo
            {
                FileName = path,
                UseShellExecute = true
            });
        }
    }
}
