using System.Net;
namespace SqlAnalyzer.Reporting
{
    internal static class HtmlUtility
    {
        public static string Encode(object v)=>WebUtility.HtmlEncode(v==null?string.Empty:v.ToString());
        public static string PageStart(string title)=>"<!doctype html><html><head><meta charset='utf-8'><title>"+Encode(title)+"</title><style>body{font-family:Segoe UI,Arial;margin:32px;color:#172033;line-height:1.4}h1{margin-bottom:4px}.subtitle{color:#526070;margin-bottom:24px}.card{border:1px solid #cbd5e1;border-radius:8px;padding:16px;margin:16px 0}.decision{font-size:18px;font-weight:700}table{border-collapse:collapse;width:100%;margin:12px 0 28px}th,td{border:1px solid #cbd5e1;padding:8px;vertical-align:top}th{background:#e8eef7;text-align:left}.Critical{background:#ffd7d7}.High{background:#ffe7cc}.Medium{background:#fff3c9}.Low{background:#edf4ff}.FixNow{font-weight:700;color:#a00000}.PlannedFix{font-weight:700;color:#8a5a00}.good{background:#e2f3e5}.bad{background:#ffdddd}.muted{color:#687386}</style></head><body>";
        public const string PageEnd="</body></html>";
    }
}
