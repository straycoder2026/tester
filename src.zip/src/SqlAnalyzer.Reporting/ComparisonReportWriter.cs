using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using SqlAnalyzer.Core;

namespace SqlAnalyzer.Reporting
{
    public sealed class ComparisonReportWriter
    {
        public void Write(ComparisonReport report, string outputFile)
        {
            var html = new StringBuilder();
            html.Append(HtmlUtility.PageStart("SQL Analyzer Diagnostic Comparison"));
            html.Append("<h1>SQL Analyzer – Diagnostic Before and After Comparison</h1>");

            WriteExecutiveSummary(html, report);
            WritePrimaryStatementComparison(html, report);
            WriteDiagnosticConclusion(html, report);
            WriteImprovementRegressionTables(html, report);
            WriteIssueChanges(html, report);

            html.Append("<div class='card'><h2>Interpretation</h2>");
            html.Append("<p>Each plan represents one captured execution. Differences may " +
                        "be caused by code, parameters, row counts, statistics, plan choice, " +
                        "cache state, concurrency, waits, or environment.</p>");
            html.Append("</div>");
            html.Append(HtmlUtility.PageEnd);

            File.WriteAllText(outputFile, html.ToString(), Encoding.UTF8);
        }

        private static void WriteExecutiveSummary(
            StringBuilder html, ComparisonReport report)
        {
            html.Append("<div class='card'><h2>Executive Summary</h2>");
            html.Append($"<div class='decision'>{HtmlUtility.Encode(report.ExecutiveSummary)}</div>");
            html.Append("<table><tr><th>Measure</th><th>Before</th><th>After</th><th>Change</th></tr>");
            html.Append($"<tr><td>Primary statement</td><td>Statement {report.PrimaryBeforeStatementId}</td>" +
                        $"<td>Statement {report.PrimaryAfterStatementId}</td><td>—</td></tr>");
            html.Append($"<tr><td>Primary elapsed</td><td>{FormatDuration(report.BeforePrimaryElapsedMs)}</td>" +
                        $"<td>{FormatDuration(report.AfterPrimaryElapsedMs)}</td>" +
                        $"<td>{report.ElapsedChangePercent:+0.0;-0.0;0.0}%</td></tr>");
            html.Append($"<tr><td>Primary CPU</td><td>{FormatDuration(report.BeforePrimaryCpuMs)}</td>" +
                        $"<td>{FormatDuration(report.AfterPrimaryCpuMs)}</td>" +
                        $"<td>{report.CpuChangePercent:+0.0;-0.0;0.0}%</td></tr>");
            html.Append($"<tr><td>Primary UDF elapsed</td><td>{FormatDuration(report.BeforePrimaryUdfElapsedMs)}</td>" +
                        $"<td>{FormatDuration(report.AfterPrimaryUdfElapsedMs)}</td>" +
                        $"<td>{report.UdfElapsedChangePercent:+0.0;-0.0;0.0}%</td></tr>");
            html.Append($"<tr><td>Score</td><td>{report.Before.Score}/100</td>" +
                        $"<td>{report.After.Score}/100</td>" +
                        $"<td>{report.After.Score - report.Before.Score:+0;-0;0}</td></tr>");
            html.Append("</table></div>");
        }

        private static void WritePrimaryStatementComparison(
            StringBuilder html, ComparisonReport report)
        {
            var before = report.Before.Statements.FirstOrDefault(x =>
                x.StatementId == report.PrimaryBeforeStatementId);
            var after = report.After.Statements.FirstOrDefault(x =>
                x.StatementId == report.PrimaryAfterStatementId);

            html.Append("<h2>Primary Statement Diagnostic Comparison</h2>");
            html.Append("<table><tr><th>Metric</th><th>Before</th><th>After</th><th>Interpretation</th></tr>");

            WriteMetricRow(html, "Elapsed time",
                report.BeforePrimaryElapsedMs,
                report.AfterPrimaryElapsedMs,
                "User-observed statement duration");

            WriteMetricRow(html, "CPU time",
                report.BeforePrimaryCpuMs,
                report.AfterPrimaryCpuMs,
                "Processor time consumed");

            WriteMetricRow(html, "UDF elapsed",
                report.BeforePrimaryUdfElapsedMs,
                report.AfterPrimaryUdfElapsedMs,
                "Time attributed to scalar UDFs");

            WriteMetricRow(html, "UDF CPU",
                report.BeforePrimaryUdfCpuMs,
                report.AfterPrimaryUdfCpuMs,
                "CPU consumed inside scalar UDFs");

            html.Append($"<tr><td>UDF share of elapsed</td>" +
                        $"<td>{Share(report.BeforePrimaryUdfElapsedMs, report.BeforePrimaryElapsedMs):N1}%</td>" +
                        $"<td>{Share(report.AfterPrimaryUdfElapsedMs, report.AfterPrimaryElapsedMs):N1}%</td>" +
                        "<td>Shows whether scalar UDF processing dominates.</td></tr>");

            html.Append($"<tr><td>Logical reads</td>" +
                        $"<td>{(before == null ? 0 : before.ActualLogicalReads):N0}</td>" +
                        $"<td>{(after == null ? 0 : after.ActualLogicalReads):N0}</td>" +
                        "<td>Buffer-cache page accesses captured for the statement.</td></tr>");

            html.Append("</table>");
        }

        private static void WriteDiagnosticConclusion(
            StringBuilder html, ComparisonReport report)
        {
            html.Append("<div class='card'><h2>Why Performance Changed</h2>");
            html.Append($"<p><b>{HtmlUtility.Encode(report.DiagnosticConclusion)}</b></p>");
            html.Append("</div>");
        }

        private static void WriteImprovementRegressionTables(
            StringBuilder html, ComparisonReport report)
        {
            html.Append("<h2>What Improved</h2><table><tr><th>Improvement</th></tr>");
            foreach (var item in report.Improvements)
                html.Append($"<tr class='good'><td>{HtmlUtility.Encode(item)}</td></tr>");
            if (report.Improvements.Count == 0)
                html.Append("<tr><td>No measurable improvement was identified.</td></tr>");
            html.Append("</table>");

            html.Append("<h2>What Became Worse</h2><table><tr><th>Regression</th></tr>");
            foreach (var item in report.Regressions)
                html.Append($"<tr class='bad'><td>{HtmlUtility.Encode(item)}</td></tr>");
            if (report.Regressions.Count == 0)
                html.Append("<tr><td>No measurable regression was identified.</td></tr>");
            html.Append("</table>");
        }

        private static void WriteIssueChanges(
            StringBuilder html, ComparisonReport report)
        {
            html.Append("<h2>New Execution-Plan Issues</h2>");
            WriteIssueTable(html, report.NewPlanIssues, "bad");
            html.Append("<h2>Resolved Execution-Plan Issues</h2>");
            WriteIssueTable(html, report.ResolvedPlanIssues, "good");
        }

        private static void WriteIssueTable(
            StringBuilder html,
            IEnumerable<ProcedureIssue> issues,
            string cssClass)
        {
            html.Append("<table><tr><th>Statement</th><th>Priority</th>" +
                        "<th>Issues</th><th>Impact</th><th>Fix location</th><th>Fix</th></tr>");

            var groups = issues.GroupBy(x => x.StatementId).OrderBy(x => x.Key).ToList();

            foreach (var group in groups)
            {
                var issueNames = string.Join("; ", group.Select(x => x.Issue).Distinct());
                var impacts = string.Join(" ", group.Select(x => x.TimeOrCostImpact)
                    .Where(x => !string.IsNullOrWhiteSpace(x)).Distinct());
                var locations = string.Join(" ", group.Select(x => x.FixLocation)
                    .Where(x => !string.IsNullOrWhiteSpace(x)).Distinct().Take(4));
                var fixes = string.Join(" ", group.Select(x => x.RecommendedFix)
                    .Where(x => !string.IsNullOrWhiteSpace(x)).Distinct());

                html.Append($"<tr class='{cssClass}'><td>Statement {group.Key}</td>" +
                            $"<td>{group.Max(x => x.Priority)}</td>" +
                            $"<td>{HtmlUtility.Encode(issueNames)}</td>" +
                            $"<td>{HtmlUtility.Encode(impacts)}</td>" +
                            $"<td>{HtmlUtility.Encode(locations)}</td>" +
                            $"<td>{HtmlUtility.Encode(fixes)}</td></tr>");
            }

            if (groups.Count == 0)
                html.Append("<tr><td colspan='6'>None.</td></tr>");

            html.Append("</table>");
        }

        private static void WriteMetricRow(
            StringBuilder html, string name, double before, double after,
            string interpretation)
        {
            var change = before == 0 ? (after == 0 ? 0 : 100) :
                (after - before) / before * 100;
            var cssClass = after < before ? "good" :
                after > before ? "bad" : string.Empty;

            html.Append($"<tr class='{cssClass}'><td>{name}</td>" +
                        $"<td>{FormatDuration(before)}</td>" +
                        $"<td>{FormatDuration(after)}</td>" +
                        $"<td>{HtmlUtility.Encode(interpretation)}; change " +
                        $"{change:+0.0;-0.0;0.0}%.</td></tr>");
        }

        private static double Share(double part, double whole) =>
            whole <= 0 ? 0 : part / whole * 100;

        private static string FormatDuration(double milliseconds)
        {
            if (milliseconds <= 0) return "0 ms";
            return milliseconds >= 1000
                ? $"{milliseconds / 1000.0:N3} sec ({milliseconds:N0} ms)"
                : $"{milliseconds:N1} ms";
        }
    }
}
