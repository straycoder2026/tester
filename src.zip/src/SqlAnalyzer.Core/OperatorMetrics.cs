using System.Collections.Generic;
namespace SqlAnalyzer.Core
{
    public sealed class OperatorMetrics
    {
        public int StatementId { get; set; }
        public int NodeId { get; set; }
        public string PhysicalOperation { get; set; }
        public string LogicalOperation { get; set; }
        public string ObjectName { get; set; }
        public string IndexName { get; set; }
        public string Predicate { get; set; }
        public string FunctionNames { get; set; }
        public long ActualLogicalReads { get; set; }
        public double EstimatedRows { get; set; }
        public double ActualRows { get; set; }
        public double ActualRowsRead { get; set; }
        public int ActualExecutions { get; set; }
        public double EstimatedOperatorCost { get; set; }
        public double EstimatedSubtreeCost { get; set; }
        public double ActualElapsedMs { get; set; }
        public double ActualCpuMs { get; set; }
        public double GrantedMemoryKb { get; set; }
        public double UsedMemoryKb { get; set; }
        public bool HasSpill { get; set; }
        public bool HasImplicitConversion { get; set; }
        public bool HasMissingIndexSuggestion { get; set; }
        public bool HasNoJoinPredicateWarning { get; set; }
        public bool HasColumnsWithNoStatisticsWarning { get; set; }
        public List<string> WarningXml { get; } = new List<string>();
    }
}
