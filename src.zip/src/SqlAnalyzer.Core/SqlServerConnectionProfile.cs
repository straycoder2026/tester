namespace SqlAnalyzer.Core
{
    public sealed class SqlServerConnectionProfile
    {
        public string ServerName { get; set; }
        public string DatabaseName { get; set; }
        public bool IntegratedSecurity { get; set; } = true;
        public string UserName { get; set; }
        public string Password { get; set; }
        public int ConnectTimeoutSeconds { get; set; } = 10;
        public bool TrustServerCertificate { get; set; } = true;
    }
}
