namespace SqlAnalyzer.Core
{
    public enum ComponentKind
    {
        ParentStatement,
        ScalarUdf,
        Sort,
        Spill,
        Filter,
        Join,
        CorrelatedSubquery,
        Lookup,
        Scan,
        OtherOperator
    }

    public sealed class StatementComponentFinding
    {
        public int StatementId { get; set; }
        public ComponentKind ComponentKind { get; set; }
        public string ComponentName { get; set; }
        public string SqlText { get; set; }
        public int? StartLine { get; set; }
        public int? EndLine { get; set; }
        public int NodeId { get; set; }
        public int Executions { get; set; }
        public double ElapsedMs { get; set; }
        public double CpuMs { get; set; }
        public long LogicalReads { get; set; }
        public string TimingStatus { get; set; }
        public string Status { get; set; }
        public string Issue { get; set; }
        public string Evidence { get; set; }
        public string FixLocation { get; set; }
        public string RecommendedFix { get; set; }
        public bool IsPrimaryCause { get; set; }
    }
}
