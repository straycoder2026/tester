namespace SqlAnalyzer.Core
{
    public sealed class StaticSqlIssue
    {
        public string RuleId { get; set; }
        public Severity Severity { get; set; }
        public RemediationPriority Priority { get; set; }
        public string Issue { get; set; }
        public int LineNumber { get; set; }
        public string FixLocation { get; set; }
        public string SourceLine { get; set; }
        public string WhyItHappened { get; set; }
        public string RecommendedFix { get; set; }
        public string FutureRisk { get; set; }
    }
}
