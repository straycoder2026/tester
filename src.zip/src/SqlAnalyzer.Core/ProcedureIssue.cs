namespace SqlAnalyzer.Core
{
    public sealed class ProcedureIssue
    {
        public string RuleId { get; set; }
        public Severity Severity { get; set; }
        public RemediationPriority Priority { get; set; }
        public string Category { get; set; }
        public string Issue { get; set; }
        public string Location { get; set; }
        public string FixLocation { get; set; }
        public int? ProcedureLine { get; set; }
        public string TimeOrCostImpact { get; set; }
        public string WhyItHappened { get; set; }
        public string RecommendedFix { get; set; }
        public string FutureRisk { get; set; }
        public string Evidence { get; set; }
        public int StatementId { get; set; }
        public int NodeId { get; set; }
        public SourceFragmentType SourceFragmentType { get; set; }
        public int? FragmentStartLine { get; set; }
        public int? FragmentEndLine { get; set; }
        public string FragmentSqlText { get; set; }
        public string FragmentDisplayName { get; set; }
    }
}
