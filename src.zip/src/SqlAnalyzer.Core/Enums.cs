namespace SqlAnalyzer.Core
{
    public enum PlanKind { Unknown, Estimated, Actual }
    public enum Severity { Informational = 0, Low = 1, Medium = 2, High = 3, Critical = 4 }
    public enum RemediationPriority { Monitor = 0, PlannedFix = 1, FixNow = 2 }
}
