namespace SqlAnalyzer.Core
{
    public enum SourceFragmentType
    {
        FullStatement,
        FilteringClause,
        JoinClause,
        SortClause,
        GroupingClause,
        CorrelatedSubquery,
        LookupSubquery,
        ScalarSubquery,
        UdfCall,
        Unknown
    }

    public sealed class SourceFragment
    {
        public int StatementId { get; set; }
        public SourceFragmentType FragmentType { get; set; }
        public int StartLine { get; set; }
        public int EndLine { get; set; }
        public string SqlText { get; set; }
        public string DisplayName { get; set; }
        public string Status { get; set; }
        public string MappingReason { get; set; }
        public string RelatedFunctionName { get; set; }
    }
}
