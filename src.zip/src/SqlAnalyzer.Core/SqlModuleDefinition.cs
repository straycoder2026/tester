namespace SqlAnalyzer.Core
{
    public sealed class SqlModuleDefinition
    {
        public int ObjectId { get; set; }
        public string SchemaName { get; set; }
        public string ObjectName { get; set; }
        public string ObjectType { get; set; }
        public string Definition { get; set; }
        public string FullName =>
            string.IsNullOrWhiteSpace(SchemaName)
                ? ObjectName
                : SchemaName + "." + ObjectName;
    }
}
