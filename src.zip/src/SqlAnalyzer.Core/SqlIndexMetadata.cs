namespace SqlAnalyzer.Core
{
    public sealed class SqlIndexMetadata
    {
        public string SchemaName { get; set; }
        public string TableName { get; set; }
        public string IndexName { get; set; }
        public bool IsUnique { get; set; }
        public bool IsPrimaryKey { get; set; }
        public bool IsDisabled { get; set; }
        public string KeyColumns { get; set; }
        public string IncludedColumns { get; set; }
    }
}
