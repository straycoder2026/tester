using System.Collections.Generic;
namespace SqlAnalyzer.Core
{
    public sealed class ComparisonReport
    {
        public AnalysisReport Before { get; set; }
        public AnalysisReport After { get; set; }
        public List<ProcedureIssue> NewPlanIssues { get; } = new List<ProcedureIssue>();
        public List<ProcedureIssue> ResolvedPlanIssues { get; } = new List<ProcedureIssue>();
        public List<StaticSqlIssue> NewStaticIssues { get; } = new List<StaticSqlIssue>();
        public List<StaticSqlIssue> ResolvedStaticIssues { get; } = new List<StaticSqlIssue>();
        public List<string> Improvements { get; } = new List<string>();
        public List<string> Regressions { get; } = new List<string>();
        public string ExecutiveSummary { get; set; }
        public int PrimaryBeforeStatementId { get; set; }
        public int PrimaryAfterStatementId { get; set; }
        public double BeforePrimaryElapsedMs { get; set; }
        public double AfterPrimaryElapsedMs { get; set; }
        public double BeforePrimaryCpuMs { get; set; }
        public double AfterPrimaryCpuMs { get; set; }
        public double BeforePrimaryUdfElapsedMs { get; set; }
        public double AfterPrimaryUdfElapsedMs { get; set; }
        public double BeforePrimaryUdfCpuMs { get; set; }
        public double AfterPrimaryUdfCpuMs { get; set; }
        public double ElapsedChangePercent { get; set; }
        public double CpuChangePercent { get; set; }
        public double UdfElapsedChangePercent { get; set; }
        public string DiagnosticConclusion { get; set; }
    }
}
