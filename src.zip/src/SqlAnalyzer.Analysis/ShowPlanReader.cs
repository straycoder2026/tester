using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using SqlAnalyzer.Core;

namespace SqlAnalyzer.Analysis
{
    public sealed class ShowPlanReader
    {
        private static readonly XNamespace Ns =
            "http://schemas.microsoft.com/sqlserver/2004/07/showplan";

        public AnalysisReport Read(string reportName, string planFile)
        {
            var document = XDocument.Load(
                planFile,
                LoadOptions.PreserveWhitespace);

            var report = new AnalysisReport
            {
                ReportName = reportName,
                PlanFile = planFile,
                PlanKind = document.Descendants(Ns + "RunTimeInformation").Any()
                    ? PlanKind.Actual
                    : PlanKind.Estimated
            };

            foreach (var statementElement in
                     document.Descendants(Ns + "StmtSimple"))
            {
                var statement = ReadStatement(statementElement);
                report.Statements.Add(statement);

                foreach (var operatorElement in
                         statementElement.Descendants(Ns + "RelOp"))
                {
                    report.Operators.Add(
                        ReadOperator(
                            statement.StatementId,
                            operatorElement,
                            statementElement));
                }

                // Recalculate statement logical reads from storage-access operators only.
                // Summing every RelOp can double-count the same page activity at parent nodes.
                statement.ActualLogicalReads = report.Operators
                    .Where(x => x.StatementId == statement.StatementId)
                    .Where(IsStorageAccess)
                    .Sum(x => x.ActualLogicalReads);
            }

            return report;
        }

        private static StatementMetrics ReadStatement(
            XElement statementElement)
        {
            var queryTimeStats = statementElement
                .Descendants(Ns + "QueryTimeStats")
                .FirstOrDefault();

            var queryPlan = statementElement
                .Descendants(Ns + "QueryPlan")
                .FirstOrDefault();

            var rootOperator = queryPlan == null
                ? null
                : queryPlan.Elements(Ns + "RelOp").FirstOrDefault();

            var rootRuntime = rootOperator == null
                ? new List<XElement>()
                : rootOperator
                    .Descendants(Ns + "RunTimeCountersPerThread")
                    .Where(x => x.Ancestors(Ns + "RelOp").FirstOrDefault() == rootOperator)
                    .ToList();

            var elapsedMs = queryTimeStats == null
                ? 0
                : XmlValue.Double(
                    queryTimeStats.Attribute("ElapsedTime"));

            var cpuMs = queryTimeStats == null
                ? 0
                : XmlValue.Double(
                    queryTimeStats.Attribute("CpuTime"));

            var udfElapsedMs = queryTimeStats == null
                ? 0
                : XmlValue.Double(
                    queryTimeStats.Attribute("UdfElapsedTime"));

            var udfCpuMs = queryTimeStats == null
                ? 0
                : XmlValue.Double(
                    queryTimeStats.Attribute("UdfCpuTime"));

            var timingSource = queryTimeStats == null
                ? "Root operator runtime fallback"
                : "StmtSimple/QueryPlan/QueryTimeStats";

            if (elapsedMs <= 0 && rootRuntime.Count > 0)
            {
                elapsedMs = rootRuntime.Max(x =>
                    XmlValue.Double(
                        x.Attribute("ActualElapsedms")));
            }

            if (cpuMs <= 0 && rootRuntime.Count > 0)
            {
                cpuMs = rootRuntime.Sum(x =>
                    XmlValue.Double(
                        x.Attribute("ActualCPUms")));
            }

            var executionCount = rootRuntime.Sum(x =>
                XmlValue.Int(
                    x.Attribute("ActualExecutions")));

            if (executionCount == 0 &&
                (elapsedMs > 0 || cpuMs > 0))
            {
                executionCount = 1;
            }

            return new StatementMetrics
            {
                StatementId =
                    XmlValue.Int(
                        statementElement.Attribute("StatementId")),
                StatementText =
                    XmlValue.Text(
                        statementElement.Attribute("StatementText")),
                StatementType =
                    XmlValue.Text(
                        statementElement.Attribute("StatementType")),
                EstimatedSubtreeCost =
                    XmlValue.Double(
                        statementElement.Attribute("StatementSubTreeCost")),
                ActualElapsedMs = elapsedMs,
                ActualCpuMs = cpuMs,
                ActualLogicalReads = 0,
                ExecutionCount = executionCount,
                UdfElapsedMs = udfElapsedMs,
                UdfCpuMs = udfCpuMs,
                TimingSource = timingSource,
                ParentObjectId = XmlValue.Int(statementElement.Attribute("ParentObjectId")),
                DatabaseName = ReadDatabaseName(statementElement)
            };
        }


        private static string ReadDatabaseName(XElement statementElement)
        {
            var database = statementElement
                .Descendants(Ns + "ColumnReference")
                .Select(x => XmlValue.CleanIdentifier(
                    XmlValue.Text(x.Attribute("Database"))))
                .FirstOrDefault(x => !string.IsNullOrWhiteSpace(x));

            return database ?? string.Empty;
        }

        private static OperatorMetrics ReadOperator(
            int statementId,
            XElement relOp,
            XElement statementElement)
        {
            // Runtime counters directly owned by this RelOp only.
            // Descendants belonging to child RelOps are deliberately excluded.
            var runtime = relOp
                .Descendants(Ns + "RunTimeCountersPerThread")
                .Where(x => x.Ancestors(Ns + "RelOp").FirstOrDefault() == relOp)
                .ToList();

            var objectElement = relOp
                .Descendants(Ns + "Object")
                .FirstOrDefault(x =>
                    x.Ancestors(Ns + "RelOp").FirstOrDefault() == relOp);

            var memoryGrant = statementElement
                .Descendants(Ns + "MemoryGrantInfo")
                .FirstOrDefault();

            var warnings = relOp
                .Descendants(Ns + "Warnings")
                .Where(x => x.Ancestors(Ns + "RelOp").FirstOrDefault() == relOp)
                .ToList();

            var functionNames = relOp
                .Descendants(Ns + "UserDefinedFunction")
                .Where(x => x.Ancestors(Ns + "RelOp").FirstOrDefault() == relOp)
                .Select(x => XmlValue.CleanIdentifier(
                    XmlValue.Text(x.Attribute("FunctionName"))))
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Distinct()
                .ToList();

            var result = new OperatorMetrics
            {
                StatementId = statementId,
                NodeId =
                    XmlValue.Int(relOp.Attribute("NodeId")),
                PhysicalOperation =
                    XmlValue.Text(relOp.Attribute("PhysicalOp")),
                LogicalOperation =
                    XmlValue.Text(relOp.Attribute("LogicalOp")),
                ObjectName = objectElement == null
                    ? string.Empty
                    : XmlValue.CleanIdentifier(
                        XmlValue.Text(
                            objectElement.Attribute("Table"))),
                IndexName = objectElement == null
                    ? string.Empty
                    : XmlValue.CleanIdentifier(
                        XmlValue.Text(
                            objectElement.Attribute("Index"))),
                Predicate = relOp
                    .Descendants(Ns + "ScalarOperator")
                    .Where(x => x.Ancestors(Ns + "RelOp").FirstOrDefault() == relOp)
                    .Select(x =>
                        XmlValue.Text(
                            x.Attribute("ScalarString")))
                    .FirstOrDefault() ?? string.Empty,
                FunctionNames = string.Join(", ", functionNames),
                EstimatedRows =
                    XmlValue.Double(
                        relOp.Attribute("EstimateRows")),
                ActualRows = runtime.Sum(x =>
                    XmlValue.Double(
                        x.Attribute("ActualRows"))),
                ActualRowsRead = runtime.Sum(x =>
                    XmlValue.Double(
                        x.Attribute("ActualRowsRead"))),
                ActualExecutions = runtime.Sum(x =>
                    XmlValue.Int(
                        x.Attribute("ActualExecutions"))),
                ActualLogicalReads = runtime.Sum(x =>
                    XmlValue.Long(
                        x.Attribute("ActualLogicalReads"))),
                EstimatedOperatorCost =
                    XmlValue.Double(
                        relOp.Attribute("EstimateCPU")) +
                    XmlValue.Double(
                        relOp.Attribute("EstimateIO")),
                EstimatedSubtreeCost =
                    XmlValue.Double(
                        relOp.Attribute(
                            "EstimatedTotalSubtreeCost")),
                ActualElapsedMs = runtime.Count == 0
                    ? 0
                    : runtime.Max(x =>
                        XmlValue.Double(
                            x.Attribute("ActualElapsedms"))),
                ActualCpuMs = runtime.Sum(x =>
                    XmlValue.Double(
                        x.Attribute("ActualCPUms"))),
                GrantedMemoryKb = memoryGrant == null
                    ? 0
                    : XmlValue.Double(
                        memoryGrant.Attribute("GrantedMemory")),
                UsedMemoryKb = memoryGrant == null
                    ? 0
                    : XmlValue.Double(
                        memoryGrant.Attribute("MaxUsedMemory")),
                HasSpill = relOp.Descendants().Any(x =>
                    x.Ancestors(Ns + "RelOp").FirstOrDefault() == relOp &&
                    x.Name.LocalName.IndexOf(
                        "Spill",
                        StringComparison.OrdinalIgnoreCase) >= 0),
                HasImplicitConversion =
                    relOp.Descendants(Ns + "Convert").Any(x =>
                        x.Ancestors(Ns + "RelOp").FirstOrDefault() == relOp &&
                        XmlValue.Text(
                            x.Attribute("Implicit")) == "1"),
                HasMissingIndexSuggestion =
                    statementElement
                        .Descendants(Ns + "MissingIndexGroup")
                        .Any(),
                HasNoJoinPredicateWarning = warnings.Any(x =>
                    XmlValue.Text(
                        x.Attribute("NoJoinPredicate")) == "1"),
                HasColumnsWithNoStatisticsWarning = warnings.Any(x =>
                    XmlValue.Text(
                        x.Attribute(
                            "ColumnsWithNoStatistics")) == "1")
            };

            foreach (var warning in warnings)
            {
                result.WarningXml.Add(
                    warning.ToString(
                        SaveOptions.DisableFormatting));
            }

            return result;
        }

        private static bool IsStorageAccess(
            OperatorMetrics op)
        {
            var physical = op.PhysicalOperation ?? string.Empty;

            return op.ActualLogicalReads > 0 &&
                   (physical.IndexOf("Scan", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    physical.IndexOf("Seek", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    physical.IndexOf("Lookup", StringComparison.OrdinalIgnoreCase) >= 0);
        }
    }
}
