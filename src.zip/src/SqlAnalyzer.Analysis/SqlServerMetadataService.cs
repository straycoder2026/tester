using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using SqlAnalyzer.Core;

namespace SqlAnalyzer.Analysis
{
    public sealed class SqlServerMetadataService
    {
        public string BuildConnectionString(SqlServerConnectionProfile profile)
        {
            var builder = new SqlConnectionStringBuilder
            {
                DataSource = profile.ServerName,
                InitialCatalog = profile.DatabaseName,
                IntegratedSecurity = profile.IntegratedSecurity,
                ConnectTimeout = profile.ConnectTimeoutSeconds,
                TrustServerCertificate = profile.TrustServerCertificate,
                Encrypt = false,
                ApplicationName = "SqlAnalyzer"
            };

            if (!profile.IntegratedSecurity)
            {
                builder.UserID = profile.UserName;
                builder.Password = profile.Password;
            }

            return builder.ConnectionString;
        }

        public void TestConnection(SqlServerConnectionProfile profile)
        {
            using (var connection = new SqlConnection(BuildConnectionString(profile)))
            {
                connection.Open();
            }
        }

        public SqlModuleDefinition GetModuleByObjectId(
            SqlServerConnectionProfile profile,
            int objectId)
        {
            if (objectId <= 0)
                return null;

            const string sql = @"
SELECT o.object_id, s.name, o.name, o.type_desc, m.definition
FROM sys.objects o
JOIN sys.schemas s ON s.schema_id = o.schema_id
LEFT JOIN sys.sql_modules m ON m.object_id = o.object_id
WHERE o.object_id = @object_id;";

            using (var connection = new SqlConnection(BuildConnectionString(profile)))
            using (var command = new SqlCommand(sql, connection))
            {
                command.Parameters.AddWithValue("@object_id", objectId);
                connection.Open();

                using (var reader = command.ExecuteReader())
                {
                    return reader.Read() ? ReadModule(reader) : null;
                }
            }
        }

        public SqlModuleDefinition GetModuleByName(
            SqlServerConnectionProfile profile,
            string objectName)
        {
            if (string.IsNullOrWhiteSpace(objectName))
                return null;

            var clean = objectName.Replace("[", "").Replace("]", "");

            const string sql = @"
SELECT o.object_id, s.name, o.name, o.type_desc, m.definition
FROM sys.objects o
JOIN sys.schemas s ON s.schema_id = o.schema_id
LEFT JOIN sys.sql_modules m ON m.object_id = o.object_id
WHERE o.object_id = OBJECT_ID(@name);";

            using (var connection = new SqlConnection(BuildConnectionString(profile)))
            using (var command = new SqlCommand(sql, connection))
            {
                command.Parameters.AddWithValue("@name", clean);
                connection.Open();

                using (var reader = command.ExecuteReader())
                {
                    return reader.Read() ? ReadModule(reader) : null;
                }
            }
        }

        private static SqlModuleDefinition ReadModule(SqlDataReader reader)
        {
            return new SqlModuleDefinition
            {
                ObjectId = reader.GetInt32(0),
                SchemaName = reader.IsDBNull(1) ? null : reader.GetString(1),
                ObjectName = reader.IsDBNull(2) ? null : reader.GetString(2),
                ObjectType = reader.IsDBNull(3) ? null : reader.GetString(3),
                Definition = reader.IsDBNull(4) ? null : reader.GetString(4)
            };
        }

        public List<SqlIndexMetadata> GetIndexes(
            SqlServerConnectionProfile profile,
            IEnumerable<string> tableNames)
        {
            var results = new List<SqlIndexMetadata>();

            foreach (var table in tableNames
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Distinct(StringComparer.OrdinalIgnoreCase))
            {
                var clean = table.Replace("[", "").Replace("]", "");

                const string sql = @"
DECLARE @id int = OBJECT_ID(@table_name);

SELECT
    s.name,
    t.name,
    i.name,
    i.is_unique,
    i.is_primary_key,
    i.is_disabled,
    STUFF((
        SELECT ', ' + c.name
        FROM sys.index_columns ic
        JOIN sys.columns c
          ON c.object_id = ic.object_id
         AND c.column_id = ic.column_id
        WHERE ic.object_id = i.object_id
          AND ic.index_id = i.index_id
          AND ic.is_included_column = 0
        ORDER BY ic.key_ordinal
        FOR XML PATH(''), TYPE
    ).value('.', 'nvarchar(max)'), 1, 2, ''),
    STUFF((
        SELECT ', ' + c.name
        FROM sys.index_columns ic
        JOIN sys.columns c
          ON c.object_id = ic.object_id
         AND c.column_id = ic.column_id
        WHERE ic.object_id = i.object_id
          AND ic.index_id = i.index_id
          AND ic.is_included_column = 1
        ORDER BY c.column_id
        FOR XML PATH(''), TYPE
    ).value('.', 'nvarchar(max)'), 1, 2, '')
FROM sys.indexes i
JOIN sys.tables t ON t.object_id = i.object_id
JOIN sys.schemas s ON s.schema_id = t.schema_id
WHERE i.object_id = @id
  AND i.index_id > 0
ORDER BY i.index_id;";

                using (var connection = new SqlConnection(BuildConnectionString(profile)))
                using (var command = new SqlCommand(sql, connection))
                {
                    command.Parameters.AddWithValue("@table_name", clean);
                    connection.Open();

                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            results.Add(new SqlIndexMetadata
                            {
                                SchemaName = reader.IsDBNull(0) ? null : reader.GetString(0),
                                TableName = reader.IsDBNull(1) ? null : reader.GetString(1),
                                IndexName = reader.IsDBNull(2) ? null : reader.GetString(2),
                                IsUnique = !reader.IsDBNull(3) && reader.GetBoolean(3),
                                IsPrimaryKey = !reader.IsDBNull(4) && reader.GetBoolean(4),
                                IsDisabled = !reader.IsDBNull(5) && reader.GetBoolean(5),
                                KeyColumns = reader.IsDBNull(6) ? null : reader.GetString(6),
                                IncludedColumns = reader.IsDBNull(7) ? null : reader.GetString(7)
                            });
                        }
                    }
                }
            }

            return results;
        }
    }
}
