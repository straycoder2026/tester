using System.IO;
using SqlAnalyzer.Core;

namespace SqlAnalyzer.Analysis
{
    public sealed class AnalysisService
    {
        public AnalysisReport Analyze(
            string reportName,
            string planFile,
            string procedureFile)
        {
            if (!File.Exists(planFile))
                throw new FileNotFoundException(
                    "Execution plan file was not found.",
                    planFile);

            var report = new ShowPlanReader().Read(reportName, planFile);

            if (!string.IsNullOrWhiteSpace(procedureFile))
            {
                new ProcedureSourceMapper().Map(report, procedureFile);
                new StoredProcedureStaticAnalyzer().Analyze(
                    procedureFile, report);

                // This call was missing from the prior generated solution.
                new SqlSourceFragmentExtractor().Extract(
                    report, procedureFile);
            }

            new PlanBottleneckAnalyzer().Analyze(report);
            new IssueSourceFragmentMapper().Map(report);
            new StatementComponentAnalyzer().Analyze(report);

            return report;
        }
    }
}
