using System;
using System.Collections.Generic;
using System.Linq;
using SqlAnalyzer.Core;

namespace SqlAnalyzer.Analysis
{
    public sealed class PlanBottleneckAnalyzer
    {
        public void Analyze(AnalysisReport report)
        {
            foreach (var statement in report.Statements)
            {
                var operators = report.Operators
                    .Where(x => x.StatementId == statement.StatementId)
                    .ToList();

                AnalyzeStatement(report, statement, operators);
            }
        }

        private static void AnalyzeStatement(
            AnalysisReport report,
            StatementMetrics statement,
            List<OperatorMetrics> operators)
        {
            var line = statement.ProcedureStartLine;

            // A memory grant belongs to the query/statement, not every RelOp.
            var memoryOperator = operators
                .OrderByDescending(x => x.GrantedMemoryKb)
                .FirstOrDefault();

            if (memoryOperator != null &&
                memoryOperator.GrantedMemoryKb > 0 &&
                memoryOperator.UsedMemoryKb > 0 &&
                memoryOperator.GrantedMemoryKb >
                    memoryOperator.UsedMemoryKb * 4)
            {
                Add(report, "EP006", "Memory", Severity.Medium,
                    RemediationPriority.PlannedFix,
                    "Statement memory grant is substantially larger than memory used",
                    statement, memoryOperator, line,
                    StatementImpact(statement),
                    "The optimizer overestimated the statement's memory requirement.",
                    "Correct cardinality estimates and parameter sensitivity before considering memory-grant hints.",
                    "Oversized grants reduce concurrency and can cause RESOURCE_SEMAPHORE waits.");
            }

            // Report spills once per statement with all affected nodes.
            var spillOperators = operators.Where(x => x.HasSpill).ToList();
            if (spillOperators.Count > 0)
            {
                var representative = spillOperators
                    .OrderByDescending(x => x.ActualElapsedMs)
                    .First();

                Add(report, "EP001", "TempDB", Severity.Critical,
                    RemediationPriority.FixNow,
                    $"Statement spilled to TempDB at {spillOperators.Count} operator(s)",
                    statement, representative, line,
                    StatementImpact(statement),
                    "One or more sort/hash operators exceeded their available memory.",
                    "Fix the statement's row-flow and cardinality causes, then retest the memory grant and spill behavior.",
                    "Spills can create TempDB I/O, concurrency pressure and unstable response time.");
            }

            // No-join-predicate is statement-significant; report once.
            var noJoin = operators.FirstOrDefault(x => x.HasNoJoinPredicateWarning);
            if (noJoin != null)
            {
                Add(report, "EP007", "Join", Severity.Critical,
                    RemediationPriority.FixNow,
                    "Join without a recognized predicate",
                    statement, noJoin, line,
                    StatementImpact(statement),
                    "A join condition is missing or SQL Server cannot recognize it.",
                    "Review the join relationship immediately.",
                    "A Cartesian product can create explosive row growth and incorrect results.");
            }

            // Missing statistics warning once per statement.
            var noStats = operators.FirstOrDefault(
                x => x.HasColumnsWithNoStatisticsWarning);
            if (noStats != null)
            {
                Add(report, "EP008", "Statistics", Severity.High,
                    RemediationPriority.PlannedFix,
                    "Columns without statistics affected optimization",
                    statement, noStats, line,
                    StatementImpact(statement),
                    "The optimizer lacked distribution information for one or more columns.",
                    "Create or permit appropriate statistics and validate the maintenance policy.",
                    "Plan quality may deteriorate as data distribution changes.");
            }

            // Missing index suggestion once per statement.
            var missingIndex = operators.FirstOrDefault(
                x => x.HasMissingIndexSuggestion);
            if (missingIndex != null)
            {
                Add(report, "EP009", "Indexing", Severity.Medium,
                    RemediationPriority.PlannedFix,
                    "SQL Server produced a missing-index suggestion",
                    statement, missingIndex, line,
                    StatementImpact(statement),
                    "The optimizer estimated that another access path could reduce cost.",
                    "Validate the suggestion against existing indexes, workload frequency and write overhead.",
                    "The query may become slower as data grows, but an unnecessary index can also harm writes.");
            }

            // Implicit conversion once per distinct object/predicate.
            foreach (var group in operators
                .Where(x => x.HasImplicitConversion)
                .GroupBy(x => (x.ObjectName ?? "") + "|" + (x.Predicate ?? "")))
            {
                var op = group.OrderByDescending(x => x.ActualElapsedMs).First();
                Add(report, "EP003", "Predicate", Severity.High,
                    RemediationPriority.PlannedFix,
                    "Implicit data-type conversion detected",
                    statement, op, line,
                    StatementImpact(statement),
                    "Parameter, expression and column data types do not match.",
                    "Align data types and avoid conversion on indexed columns.",
                    "The conversion can block index seeks and increase CPU and I/O as data grows.");
            }

            // Cardinality mismatch: only report leaf access or join nodes,
            // not every parent node carrying the same bad row count upward.
            var cardinalityCandidates = operators
                .Where(IsCardinalityRootCauseCandidate)
                .Select(x => new { Operator = x, Ratio = Ratio(x.EstimatedRows, x.ActualRows) })
                .Where(x => x.Ratio >= 10)
                .GroupBy(x =>
                    (x.Operator.ObjectName ?? "") + "|" +
                    (x.Operator.PhysicalOperation ?? "") + "|" +
                    Bucket(x.Ratio))
                .Select(g => g.OrderByDescending(x => x.Ratio).First())
                .OrderByDescending(x => x.Ratio)
                .Take(10)
                .ToList();

            foreach (var candidate in cardinalityCandidates)
            {
                var op = candidate.Operator;
                var severity = candidate.Ratio >= 100
                    ? Severity.Critical
                    : Severity.High;

                Add(report, "EP002", "Cardinality", severity,
                    candidate.Ratio >= 100
                        ? RemediationPriority.FixNow
                        : RemediationPriority.PlannedFix,
                    "Root cardinality estimate mismatch",
                    statement, op, line,
                    StatementImpact(statement),
                    $"The optimizer estimated {op.EstimatedRows:N0} rows but observed " +
                    $"{op.ActualRows:N0} rows ({candidate.Ratio:N1}x mismatch).",
                    "Validate statistics, representative parameter values, data skew, predicates and temp-object estimates at this root access/join point.",
                    "Bad estimates can cause poor joins, wrong memory grants, spills and unstable plans.");
            }

            // Excess rows read: report once per object/index.
            foreach (var group in operators
                .Where(x => IsStorageAccess(x) &&
                            x.ActualRows > 0 &&
                            x.ActualRowsRead > 0 &&
                            x.ActualRowsRead / x.ActualRows >= 20)
                .GroupBy(x => (x.ObjectName ?? "") + "|" + (x.IndexName ?? "")))
            {
                var op = group
                    .OrderByDescending(x => x.ActualRowsRead / Math.Max(1, x.ActualRows))
                    .First();

                Add(report, "EP005", "Selectivity", Severity.High,
                    RemediationPriority.PlannedFix,
                    "Excessive rows read compared with rows returned",
                    statement, op, line,
                    StatementImpact(statement),
                    "The predicate is not selective, not SARGable or is evaluated as a residual predicate.",
                    "Review predicate form, index key order, filtered indexes and unnecessary row access.",
                    "I/O and CPU will rise as the table grows.");
            }

            // Key lookup once per object/index.
            foreach (var group in operators
                .Where(x => Contains(x.PhysicalOperation, "Lookup") &&
                            x.ActualExecutions > 100)
                .GroupBy(x => (x.ObjectName ?? "") + "|" + (x.IndexName ?? "")))
            {
                var op = group.OrderByDescending(x => x.ActualExecutions).First();
                Add(report, "EP004", "Indexing",
                    op.ActualExecutions > 10000 ? Severity.High : Severity.Medium,
                    op.ActualExecutions > 10000
                        ? RemediationPriority.FixNow
                        : RemediationPriority.PlannedFix,
                    "Repeated key lookup detected",
                    statement, op, line,
                    StatementImpact(statement),
                    "The nonclustered index does not contain all columns required by the query.",
                    "Evaluate a covering index or query-column reduction after measuring write and storage impact.",
                    "Lookup cost grows with rows returned and can become a random-I/O bottleneck.");
            }

            // Runtime driver: based only on actual operator counters in this plan.
            if (report.PlanKind == PlanKind.Actual)
            {
                var dominant = operators
                    .Where(x => x.ActualElapsedMs > 0)
                    .OrderByDescending(x => x.ActualElapsedMs)
                    .FirstOrDefault();

                if (dominant != null &&
                    statement.ActualElapsedMs >= 1000 &&
                    dominant.ActualElapsedMs >= statement.ActualElapsedMs * 0.50)
                {
                    Add(report, "EP011", "Runtime", Severity.High,
                        RemediationPriority.PlannedFix,
                        "One operator dominates the captured statement runtime",
                        statement, dominant, line,
                        $"{FormatDuration(dominant.ActualElapsedMs)} operator elapsed; " +
                        $"{FormatDuration(statement.ActualElapsedMs)} statement elapsed.",
                        "The captured statement spent most of its recorded operator time in one operator.",
                        "Review row reduction, predicates, join order and supporting indexes before this operator.",
                        "The dominant operator can become a larger bottleneck as volume or concurrency increases.");
                }
            }
        }

        private static void Add(
            AnalysisReport report,
            string id,
            string category,
            Severity severity,
            RemediationPriority priority,
            string issue,
            StatementMetrics statement,
            OperatorMetrics op,
            int? line,
            string impact,
            string why,
            string fix,
            string future)
        {
            report.PlanIssues.Add(new ProcedureIssue
            {
                RuleId = id,
                Category = category,
                Severity = severity,
                Priority = priority,
                Issue = issue,
                Location = $"Statement {statement.StatementId}, Node {op.NodeId}, " +
                           $"{op.PhysicalOperation}, object {op.ObjectName}, index {op.IndexName}",
                ProcedureLine = line,
                TimeOrCostImpact = impact,
                WhyItHappened = why,
                FixLocation = BuildFixLocation(statement, op, line),
                RecommendedFix = fix,
                FutureRisk = future,
                Evidence = $"Estimated rows {op.EstimatedRows:N0}; actual rows " +
                           $"{op.ActualRows:N0}; rows read {op.ActualRowsRead:N0}; " +
                           $"executions {op.ActualExecutions:N0}; logical reads " +
                           $"{op.ActualLogicalReads:N0}; subtree cost " +
                           $"{op.EstimatedSubtreeCost:N4}; functions {op.FunctionNames}.",
                StatementId = statement.StatementId,
                NodeId = op.NodeId
            });
        }

        private static string StatementImpact(StatementMetrics statement)
        {
            if (statement.ActualElapsedMs > 0)
            {
                return $"{statement.ExecutionCount:N0} captured execution(s); " +
                       $"{FormatDuration(statement.ActualElapsedMs)} elapsed; " +
                       $"{FormatDuration(statement.ActualCpuMs)} CPU; " +
                       $"{statement.ActualLogicalReads:N0} logical reads; " +
                       $"timing source: {statement.TimingSource}.";
            }

            return $"Actual time unavailable; estimated subtree cost " +
                   $"{statement.EstimatedSubtreeCost:N4}.";
        }

        private static string BuildFixLocation(
            StatementMetrics statement,
            OperatorMetrics op,
            int? line)
        {
            var baseLocation = line.HasValue
                ? $"Stored procedure line {line.Value}, Statement {statement.StatementId}"
                : $"Statement {statement.StatementId}";

            if (!string.IsNullOrWhiteSpace(op.FunctionNames))
                return $"{baseLocation}; scalar function expression {op.FunctionNames}.";

            if (!string.IsNullOrWhiteSpace(op.ObjectName))
                return $"{baseLocation}; object {op.ObjectName}" +
                       (string.IsNullOrWhiteSpace(op.IndexName)
                           ? "."
                           : $", index {op.IndexName}.");

            return $"{baseLocation}; {op.PhysicalOperation} operator.";
        }

        private static bool IsCardinalityRootCauseCandidate(OperatorMetrics op)
        {
            return IsStorageAccess(op) ||
                   Contains(op.PhysicalOperation, "Join") ||
                   Contains(op.PhysicalOperation, "Apply");
        }

        private static bool IsStorageAccess(OperatorMetrics op)
        {
            return Contains(op.PhysicalOperation, "Scan") ||
                   Contains(op.PhysicalOperation, "Seek") ||
                   Contains(op.PhysicalOperation, "Lookup");
        }

        private static string Bucket(double ratio)
        {
            if (ratio >= 10000) return "10000+";
            if (ratio >= 1000) return "1000+";
            if (ratio >= 100) return "100+";
            return "10+";
        }

        private static double Ratio(double estimated, double actual)
        {
            if (estimated <= 0 || actual <= 0) return 0;
            return Math.Max(actual / estimated, estimated / actual);
        }

        private static bool Contains(string value, string token)
        {
            return (value ?? string.Empty).IndexOf(
                token,
                StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private static string FormatDuration(double milliseconds)
        {
            return milliseconds >= 1000
                ? $"{milliseconds / 1000.0:N3} sec ({milliseconds:N0} ms)"
                : $"{milliseconds:N1} ms";
        }
    }
}
