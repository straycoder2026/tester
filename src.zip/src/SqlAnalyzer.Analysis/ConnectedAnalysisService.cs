using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using SqlAnalyzer.Core;

namespace SqlAnalyzer.Analysis
{
    public sealed class ConnectedAnalysisService
    {
        private static readonly Regex FunctionRegex = new Regex(
            @"(?<name>(?:\[[^\]]+\]|\w+)\.(?:\[[^\]]+\]|\w+))\s*\(",
            RegexOptions.IgnoreCase | RegexOptions.Compiled);

        public AnalysisReport Analyze(
            string reportName,
            string planFile,
            SqlServerConnectionProfile profile)
        {
            var metadata = new SqlServerMetadataService();
            metadata.TestConnection(profile);

            var report = new AnalysisService().Analyze(
                reportName, planFile, null);

            var objectId = report.Statements
                .Where(x => x.ParentObjectId > 0)
                .Select(x => x.ParentObjectId)
                .FirstOrDefault();

            var parent = metadata.GetModuleByObjectId(profile, objectId);

            if (parent != null &&
                !string.IsNullOrWhiteSpace(parent.Definition))
            {
                var temp = Path.Combine(
                    Path.GetTempPath(),
                    "SqlAnalyzer_" + Guid.NewGuid().ToString("N") + ".sql");

                File.WriteAllText(temp, parent.Definition);

                try
                {
                    report = new AnalysisService().Analyze(
                        reportName, planFile, temp);
                }
                finally
                {
                    try { File.Delete(temp); } catch { }
                }

                report.ConnectedModules.Add(parent);
            }

            report.ConnectedDatabaseUsed = true;
            report.ConnectedServer = profile.ServerName;
            report.ConnectedDatabase = profile.DatabaseName;

            foreach (var functionName in DiscoverFunctions(report))
            {
                var module = metadata.GetModuleByName(
                    profile, functionName);

                if (module != null &&
                    !string.IsNullOrWhiteSpace(module.Definition) &&
                    !report.ConnectedModules.Any(x =>
                        x.ObjectId == module.ObjectId))
                {
                    report.ConnectedModules.Add(module);
                }
            }

            var tables = report.Operators
                .Select(x => x.ObjectName)
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Distinct(StringComparer.OrdinalIgnoreCase);

            report.ConnectedIndexes.AddRange(
                metadata.GetIndexes(profile, tables));

            return report;
        }

        private static IEnumerable<string> DiscoverFunctions(
            AnalysisReport report)
        {
            var names = new HashSet<string>(
                StringComparer.OrdinalIgnoreCase);

            foreach (var statement in report.Statements)
            {
                foreach (Match match in FunctionRegex.Matches(
                    statement.StatementText ?? string.Empty))
                {
                    var name = Normalize(
                        match.Groups["name"].Value);

                    if (LooksLikeUdf(name))
                        names.Add(name);
                }
            }

            foreach (var op in report.Operators)
            {
                foreach (var value in (op.FunctionNames ?? string.Empty)
                    .Split(new[] { ',' },
                        StringSplitOptions.RemoveEmptyEntries))
                {
                    var name = Normalize(value);
                    if (LooksLikeUdf(name))
                        names.Add(name);
                }
            }

            return names;
        }

        private static string Normalize(string value)
        {
            var clean = (value ?? string.Empty)
                .Replace("[", string.Empty)
                .Replace("]", string.Empty)
                .Trim();

            var parts = clean.Split('.');
            return parts.Length >= 2
                ? parts[parts.Length - 2] + "." +
                  parts[parts.Length - 1]
                : clean;
        }

        private static bool LooksLikeUdf(string value)
        {
            var lower = (value ?? string.Empty)
                .ToLowerInvariant();

            return lower.Contains(".f_") ||
                   lower.Contains(".fn_") ||
                   lower.StartsWith("dbo.");
        }
    }
}
