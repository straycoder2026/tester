using System;
using System.IO;
using System.Text.RegularExpressions;
using SqlAnalyzer.Core;
namespace SqlAnalyzer.Analysis
{
    public sealed class StoredProcedureStaticAnalyzer
    {
        public void Analyze(string procedureFile,AnalysisReport report)
        {
            if(string.IsNullOrWhiteSpace(procedureFile)||!File.Exists(procedureFile))return; var lines=File.ReadAllLines(procedureFile);
            for(var i=0;i<lines.Length;i++)
            {
                var t=lines[i];var line=i+1;
                if(Regex.IsMatch(t,@"SELECT\s+\*",RegexOptions.IgnoreCase))Add(report,"SQL001",Severity.Medium,RemediationPriority.PlannedFix,line,t,"SELECT * returns columns that may not be required.","List only required columns.","Future schema growth can increase I/O, network traffic and memory use.");
                if(Regex.IsMatch(t,@"(NOLOCK|READUNCOMMITTED)",RegexOptions.IgnoreCase))Add(report,"SQL002",Severity.High,RemediationPriority.PlannedFix,line,t,"The query permits dirty or inconsistent reads.","Confirm the requirement and consider snapshot-based isolation.","Incorrect business results may occur under concurrent updates.");
                if(Regex.IsMatch(t,@"CURSOR",RegexOptions.IgnoreCase))Add(report,"SQL003",Severity.High,RemediationPriority.PlannedFix,line,t,"Cursor-based row-by-row processing was detected.","Evaluate a set-based rewrite or controlled batching.","Execution time commonly grows linearly or worse as row count increases.");
                if(Regex.IsMatch(t,@"WHILE",RegexOptions.IgnoreCase))Add(report,"SQL004",Severity.Medium,RemediationPriority.PlannedFix,line,t,"Loop-based processing was detected.","Assess whether the logic can be converted to set-based SQL.","Loops can become CPU and transaction-duration bottlenecks at scale.");
                if(Regex.IsMatch(t,@"WHERE.*(ISNULL|COALESCE|CONVERT|CAST|UPPER|LOWER|LTRIM|RTRIM)\s*\(",RegexOptions.IgnoreCase))Add(report,"SQL005",Severity.High,RemediationPriority.PlannedFix,line,t,"A function appears to be applied in a WHERE predicate.","Move transformation away from the indexed column or use a persisted computed column.","The predicate can become non-SARGable and force scans as data grows.");
                if(Regex.IsMatch(t,@"OPTION\s*\(\s*RECOMPILE\s*\)",RegexOptions.IgnoreCase))Add(report,"SQL006",Severity.Low,RemediationPriority.Monitor,line,t,"OPTION(RECOMPILE) was detected.","Retain only when parameter sensitivity justifies compilation overhead.","High execution frequency can create avoidable CPU compilation cost.");
                if(Regex.IsMatch(t,@"MERGE",RegexOptions.IgnoreCase))Add(report,"SQL007",Severity.Medium,RemediationPriority.PlannedFix,line,t,"MERGE was detected.","Validate concurrency and consider separate INSERT/UPDATE operations.","Complex matching and concurrency can create correctness or blocking risk.");
            }
        }
        private static void Add(AnalysisReport r,string id,Severity sev,RemediationPriority p,int line,string src,string why,string fix,string future){r.StaticSqlIssues.Add(new StaticSqlIssue{RuleId=id,Severity=sev,Priority=p,Issue=why,LineNumber=line,SourceLine=src.Trim(),WhyItHappened=why,RecommendedFix=fix,FutureRisk=future});}
    }
}
