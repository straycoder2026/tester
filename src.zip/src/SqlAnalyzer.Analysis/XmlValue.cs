using System.Globalization;
using System.Xml.Linq;
namespace SqlAnalyzer.Analysis
{
    internal static class XmlValue
    {
        public static string Text(XAttribute a)=>a==null?string.Empty:a.Value;
        public static int Int(XAttribute a){int v;return a!=null&&int.TryParse(a.Value,out v)?v:0;}
        public static long Long(XAttribute a){long v;return a!=null&&long.TryParse(a.Value,out v)?v:0;}
        public static double Double(XAttribute a){double v;return a!=null&&double.TryParse(a.Value,NumberStyles.Any,CultureInfo.InvariantCulture,out v)?v:0;}
        public static string CleanIdentifier(string v)=>(v??string.Empty).Replace("[",string.Empty).Replace("]",string.Empty);
    }
}
