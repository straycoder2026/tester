using System;
using System.Text.RegularExpressions;
using SqlAnalyzer.Core;
namespace SqlAnalyzer.Analysis
{
    public sealed class ProcedureSourceMapper
    {
        public void Map(AnalysisReport report,string procedureFile)
        {
            if(string.IsNullOrWhiteSpace(procedureFile))return; var lines=System.IO.File.ReadAllLines(procedureFile); report.ProcedureFile=procedureFile;
            foreach(var s in report.Statements)
            {
                var target=Normalize(s.StatementText); if(target.Length<8){s.ProcedureLineStatus="Statement text was too short to map.";continue;}
                for(var start=0;start<lines.Length;start++)
                {
                    var block=string.Empty;
                    for(var end=start;end<Math.Min(lines.Length,start+120);end++)
                    {
                        block+=" "+lines[end]; var n=Normalize(block);
                        if(n.Contains(target)||(target.Contains(n)&&n.Length>50)){s.ProcedureStartLine=start+1;s.ProcedureEndLine=end+1;s.ProcedureLineStatus="Matched from plan statement text.";break;}
                    }
                    if(s.ProcedureStartLine.HasValue)break;
                }
                if(!s.ProcedureStartLine.HasValue)s.ProcedureLineStatus="No reliable source-line match was found.";
            }
        }
        private static string Normalize(string v){if(string.IsNullOrWhiteSpace(v))return string.Empty;var noComments=Regex.Replace(v,@"--.*?$|/\*.*?\*/"," ",RegexOptions.Multiline|RegexOptions.Singleline);return Regex.Replace(noComments,@"\s+"," ").Trim().ToLowerInvariant();}
    }
}
