using System;
using System.Collections.Generic;
using System.Linq;
using SqlAnalyzer.Core;

namespace SqlAnalyzer.Analysis
{
    public sealed class IssueSourceFragmentMapper
    {
        public void Map(AnalysisReport report)
        {
            foreach (var issue in report.PlanIssues)
            {
                var candidates = report.SourceFragments
                    .Where(x => x.StatementId == issue.StatementId)
                    .ToList();

                var selected = SelectBestFragment(issue, candidates);

                if (selected == null)
                    continue;

                issue.SourceFragmentType = selected.FragmentType;
                issue.FragmentStartLine = selected.StartLine;
                issue.FragmentEndLine = selected.EndLine;
                issue.FragmentSqlText = selected.SqlText;
                issue.FragmentDisplayName = selected.DisplayName;

                issue.FixLocation =
                    $"Stored procedure lines {selected.StartLine}" +
                    (selected.EndLine != selected.StartLine
                        ? $"-{selected.EndLine}"
                        : string.Empty) +
                    $"; {selected.DisplayName}.";
            }
        }

        private static SourceFragment SelectBestFragment(
            ProcedureIssue issue,
            List<SourceFragment> fragments)
        {
            if (fragments.Count == 0)
                return null;

            var preferredTypes = PreferredTypes(issue);

            foreach (var type in preferredTypes)
            {
                var matches = fragments
                    .Where(x => x.FragmentType == type)
                    .ToList();

                if (matches.Count == 0)
                    continue;

                if (type == SourceFragmentType.UdfCall)
                {
                    var functionMatch = matches.FirstOrDefault(x =>
                        !string.IsNullOrWhiteSpace(x.RelatedFunctionName) &&
                        Contains(issue.Evidence, x.RelatedFunctionName));

                    if (functionMatch != null)
                        return functionMatch;
                }

                return matches
                    .OrderBy(x => x.EndLine - x.StartLine)
                    .First();
            }

            return fragments.FirstOrDefault(
                x => x.FragmentType == SourceFragmentType.FullStatement);
        }

        private static IEnumerable<SourceFragmentType> PreferredTypes(
            ProcedureIssue issue)
        {
            switch ((issue.Category ?? string.Empty).ToLowerInvariant())
            {
                case "predicate":
                case "selectivity":
                    return new[]
                    {
                        SourceFragmentType.FilteringClause,
                        SourceFragmentType.JoinClause,
                        SourceFragmentType.CorrelatedSubquery,
                        SourceFragmentType.FullStatement
                    };

                case "join":
                case "cardinality":
                    return new[]
                    {
                        SourceFragmentType.JoinClause,
                        SourceFragmentType.CorrelatedSubquery,
                        SourceFragmentType.FilteringClause,
                        SourceFragmentType.FullStatement
                    };

                case "sort":
                case "tempdb":
                    return new[]
                    {
                        SourceFragmentType.SortClause,
                        SourceFragmentType.GroupingClause,
                        SourceFragmentType.FullStatement
                    };

                case "runtime":
                    return new[]
                    {
                        SourceFragmentType.UdfCall,
                        SourceFragmentType.CorrelatedSubquery,
                        SourceFragmentType.LookupSubquery,
                        SourceFragmentType.FullStatement
                    };

                case "indexing":
                    return new[]
                    {
                        SourceFragmentType.LookupSubquery,
                        SourceFragmentType.FilteringClause,
                        SourceFragmentType.JoinClause,
                        SourceFragmentType.FullStatement
                    };

                default:
                    return new[]
                    {
                        SourceFragmentType.FullStatement
                    };
            }
        }

        private static bool Contains(
            string value,
            string token)
        {
            return (value ?? string.Empty).IndexOf(
                token ?? string.Empty,
                StringComparison.OrdinalIgnoreCase) >= 0;
        }
    }
}
