using System;
using System.Linq;
using SqlAnalyzer.Core;

namespace SqlAnalyzer.Analysis
{
    public sealed class ComparisonService
    {
        public ComparisonReport Compare(AnalysisReport before, AnalysisReport after)
        {
            var result = new ComparisonReport { Before = before, After = after };

            foreach (var issue in after.PlanIssues)
                if (!before.PlanIssues.Any(x => Same(x, issue)))
                    result.NewPlanIssues.Add(issue);

            foreach (var issue in before.PlanIssues)
                if (!after.PlanIssues.Any(x => Same(x, issue)))
                    result.ResolvedPlanIssues.Add(issue);

            foreach (var issue in after.StaticSqlIssues)
                if (!before.StaticSqlIssues.Any(x => Same(x, issue)))
                    result.NewStaticIssues.Add(issue);

            foreach (var issue in before.StaticSqlIssues)
                if (!after.StaticSqlIssues.Any(x => Same(x, issue)))
                    result.ResolvedStaticIssues.Add(issue);

            PopulatePrimaryStatementMetrics(before, after, result);
            CompareMetrics(before, after, result);
            result.ExecutiveSummary = BuildExecutiveSummary(result);
            result.DiagnosticConclusion = BuildDiagnosticConclusion(result);
            return result;
        }

        private static void PopulatePrimaryStatementMetrics(
            AnalysisReport before, AnalysisReport after, ComparisonReport result)
        {
            var beforePrimary = before.Statements
                .OrderByDescending(x => x.ActualElapsedMs > 0
                    ? x.ActualElapsedMs : x.EstimatedSubtreeCost)
                .FirstOrDefault();

            var afterPrimary = after.Statements
                .OrderByDescending(x => x.ActualElapsedMs > 0
                    ? x.ActualElapsedMs : x.EstimatedSubtreeCost)
                .FirstOrDefault();

            if (beforePrimary != null)
            {
                result.PrimaryBeforeStatementId = beforePrimary.StatementId;
                result.BeforePrimaryElapsedMs = beforePrimary.ActualElapsedMs;
                result.BeforePrimaryCpuMs = beforePrimary.ActualCpuMs;
                result.BeforePrimaryUdfElapsedMs = beforePrimary.UdfElapsedMs;
                result.BeforePrimaryUdfCpuMs = beforePrimary.UdfCpuMs;
            }

            if (afterPrimary != null)
            {
                result.PrimaryAfterStatementId = afterPrimary.StatementId;
                result.AfterPrimaryElapsedMs = afterPrimary.ActualElapsedMs;
                result.AfterPrimaryCpuMs = afterPrimary.ActualCpuMs;
                result.AfterPrimaryUdfElapsedMs = afterPrimary.UdfElapsedMs;
                result.AfterPrimaryUdfCpuMs = afterPrimary.UdfCpuMs;
            }

            result.ElapsedChangePercent = PercentChange(
                result.BeforePrimaryElapsedMs, result.AfterPrimaryElapsedMs);
            result.CpuChangePercent = PercentChange(
                result.BeforePrimaryCpuMs, result.AfterPrimaryCpuMs);
            result.UdfElapsedChangePercent = PercentChange(
                result.BeforePrimaryUdfElapsedMs, result.AfterPrimaryUdfElapsedMs);
        }

        private static void CompareMetrics(
            AnalysisReport before, AnalysisReport after, ComparisonReport result)
        {
            AddMetric(result, "Captured statement elapsed time",
                before.Statements.Sum(x => x.ActualElapsedMs),
                after.Statements.Sum(x => x.ActualElapsedMs), "ms");

            AddMetric(result, "Captured statement CPU time",
                before.Statements.Sum(x => x.ActualCpuMs),
                after.Statements.Sum(x => x.ActualCpuMs), "ms");

            AddMetric(result, "Captured UDF elapsed time",
                before.Statements.Sum(x => x.UdfElapsedMs),
                after.Statements.Sum(x => x.UdfElapsedMs), "ms");

            AddMetric(result, "Logical reads",
                before.Statements.Sum(x => x.ActualLogicalReads),
                after.Statements.Sum(x => x.ActualLogicalReads), "reads");

            if (after.Score > before.Score)
                result.Improvements.Add(
                    $"Executive score improved from {before.Score} to {after.Score}.");
            else if (after.Score < before.Score)
                result.Regressions.Add(
                    $"Executive score declined from {before.Score} to {after.Score}.");

            if (result.ResolvedPlanIssues.Count > 0)
                result.Improvements.Add(
                    $"{result.ResolvedPlanIssues.Count} execution-plan issue(s) were resolved.");

            if (result.NewPlanIssues.Count > 0)
                result.Regressions.Add(
                    $"{result.NewPlanIssues.Count} new execution-plan issue(s) were introduced.");
        }

        private static void AddMetric(
            ComparisonReport result, string name, double before, double after, string unit)
        {
            if (before <= 0 && after <= 0) return;

            var delta = after - before;
            var percent = PercentChange(before, after);
            var message =
                $"{name}: before {before:N1} {unit}; after {after:N1} {unit}; " +
                $"change {delta:+0.0;-0.0;0.0} {unit} ({percent:+0.0;-0.0;0.0}%).";

            if (after < before) result.Improvements.Add(message);
            else if (after > before) result.Regressions.Add(message);
        }

        private static string BuildExecutiveSummary(ComparisonReport result)
        {
            if (result.NewPlanIssues.Any(x =>
                    x.Priority == RemediationPriority.FixNow) ||
                result.NewStaticIssues.Any(x =>
                    x.Priority == RemediationPriority.FixNow))
                return "The after version introduces immediate-fix issues. " +
                       "Release approval should be withheld until reviewed.";

            if (result.AfterPrimaryElapsedMs > 0 &&
                result.BeforePrimaryElapsedMs > 0)
            {
                if (result.AfterPrimaryElapsedMs <
                    result.BeforePrimaryElapsedMs * 0.75)
                    return "The after execution is materially faster, subject to " +
                           "functional and representative-load validation.";

                if (result.AfterPrimaryElapsedMs >
                    result.BeforePrimaryElapsedMs * 1.25)
                    return "The after execution is materially slower. Approval " +
                           "should require a corrective plan.";
            }

            return result.After.Score > result.Before.Score
                ? "The after version shows an overall improvement."
                : result.After.Score < result.Before.Score
                    ? "The after version has regressed."
                    : "No material overall score change was detected.";
        }

        private static string BuildDiagnosticConclusion(ComparisonReport result)
        {
            if (result.BeforePrimaryElapsedMs <= 0 ||
                result.AfterPrimaryElapsedMs <= 0)
                return "A runtime diagnosis cannot be completed because one or both " +
                       "plans lack statement-level actual elapsed time.";

            var beforeUdfShare = Share(
                result.BeforePrimaryUdfElapsedMs, result.BeforePrimaryElapsedMs);
            var afterUdfShare = Share(
                result.AfterPrimaryUdfElapsedMs, result.AfterPrimaryElapsedMs);

            if (result.AfterPrimaryElapsedMs >
                result.BeforePrimaryElapsedMs * 5 && afterUdfShare >= 70)
                return $"The slowdown is dominated by scalar UDF processing. " +
                       $"The primary statement changed from " +
                       $"{FormatDuration(result.BeforePrimaryElapsedMs)} to " +
                       $"{FormatDuration(result.AfterPrimaryElapsedMs)}, and UDF time " +
                       $"represents {afterUdfShare:N1}% of the slower execution. Reduce " +
                       "rows before UDF evaluation and replace row-by-row scalar logic.";

            if (result.AfterPrimaryElapsedMs <
                result.BeforePrimaryElapsedMs * 0.25 &&
                result.BeforePrimaryUdfElapsedMs > 0)
                return $"The faster execution reduced the primary statement from " +
                       $"{FormatDuration(result.BeforePrimaryElapsedMs)} to " +
                       $"{FormatDuration(result.AfterPrimaryElapsedMs)}. UDF elapsed " +
                       $"changed from {FormatDuration(result.BeforePrimaryUdfElapsedMs)} " +
                       $"to {FormatDuration(result.AfterPrimaryUdfElapsedMs)}. The main " +
                       "improvement is consistent with reduced scalar-function workload " +
                       "or earlier row reduction.";

            if (result.AfterPrimaryElapsedMs >
                result.BeforePrimaryElapsedMs * 2)
                return "The after execution is substantially slower, but UDF time does " +
                       "not explain most of the increase. Review waits, reads, cardinality, " +
                       "spills, parallelism and parameter-sensitive plan differences.";

            return $"Primary elapsed-time change: " +
                   $"{result.ElapsedChangePercent:+0.0;-0.0;0.0}%. Before UDF share: " +
                   $"{beforeUdfShare:N1}%; after UDF share: {afterUdfShare:N1}%.";
        }

        private static bool Same(ProcedureIssue a, ProcedureIssue b) =>
            a.RuleId == b.RuleId &&
            a.StatementId == b.StatementId &&
            string.Equals(a.Category, b.Category,
                StringComparison.OrdinalIgnoreCase);

        private static bool Same(StaticSqlIssue a, StaticSqlIssue b) =>
            a.RuleId == b.RuleId && a.LineNumber == b.LineNumber;

        private static double PercentChange(double before, double after) =>
            before == 0 ? (after == 0 ? 0 : 100) :
            (after - before) / before * 100;

        private static double Share(double part, double whole) =>
            whole <= 0 ? 0 : part / whole * 100;

        private static string FormatDuration(double milliseconds) =>
            milliseconds >= 1000
                ? $"{milliseconds / 1000.0:N3} sec"
                : $"{milliseconds:N1} ms";
    }
}
