using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using SqlAnalyzer.Core;

namespace SqlAnalyzer.Analysis
{
    public sealed class StatementComponentAnalyzer
    {
        private static readonly Regex UdfRegex = new Regex(
            @"(?<name>(?:\[[^\]]+\]|\w+)\.(?:\[[^\]]+\]|\w+))\s*\(",
            RegexOptions.IgnoreCase | RegexOptions.Compiled);

        public void Analyze(AnalysisReport report)
        {
            foreach (var statement in report.Statements)
            {
                var operators = report.Operators
                    .Where(x => x.StatementId == statement.StatementId)
                    .ToList();

                AddParentStatement(report, statement);
                AddUdfFindings(report, statement, operators);
                AddSortAndSpillFindings(report, statement, operators);
                AddFilterFinding(report, statement, operators);
                AddLookupFindings(report, statement, operators);
                AddJoinFindings(report, statement, operators);
            }
        }

        private static void AddParentStatement(
            AnalysisReport report,
            StatementMetrics statement)
        {
            var status = statement.ActualElapsedMs >= 30000
                ? "Critical"
                : statement.ActualElapsedMs >= 5000
                    ? "High"
                    : statement.ActualElapsedMs >= 1000
                        ? "Review"
                        : "Acceptable";

            report.ComponentFindings.Add(new StatementComponentFinding
            {
                StatementId = statement.StatementId,
                ComponentKind = ComponentKind.ParentStatement,
                ComponentName = $"Statement {statement.StatementId}",
                SqlText = statement.StatementText,
                StartLine = statement.ProcedureStartLine,
                EndLine = statement.ProcedureEndLine,
                Executions = statement.ExecutionCount,
                ElapsedMs = statement.ActualElapsedMs,
                CpuMs = statement.ActualCpuMs,
                LogicalReads = statement.ActualLogicalReads,
                TimingStatus = "Measured at parent statement level",
                Status = status,
                Issue = statement.ActualElapsedMs >= 5000
                    ? "The complete statement is slow in this captured execution."
                    : "Parent statement timing context.",
                Evidence = $"Elapsed {statement.ActualElapsedMs:N0} ms; CPU " +
                           $"{statement.ActualCpuMs:N0} ms; UDF elapsed " +
                           $"{statement.UdfElapsedMs:N0} ms; logical reads " +
                           $"{statement.ActualLogicalReads:N0}.",
                FixLocation = statement.ProcedureStartLine.HasValue
                    ? $"Stored procedure lines {statement.ProcedureStartLine}" +
                      (statement.ProcedureEndLine.HasValue
                          ? $"-{statement.ProcedureEndLine}"
                          : string.Empty)
                    : $"Statement {statement.StatementId}",
                RecommendedFix = "Use the component findings below to fix the dominant cause.",
                IsPrimaryCause = false
            });
        }

        private static void AddUdfFindings(
            AnalysisReport report,
            StatementMetrics statement,
            List<OperatorMetrics> operators)
        {
            var names = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            foreach (Match match in UdfRegex.Matches(statement.StatementText ?? string.Empty))
            {
                var name = Clean(match.Groups["name"].Value);
                if (LooksLikeUserFunction(name))
                    names.Add(name);
            }

            foreach (var op in operators)
            {
                foreach (var name in SplitNames(op.FunctionNames))
                    names.Add(name);
            }

            if (statement.UdfElapsedMs <= 0 && names.Count == 0)
                return;

            var udfShare = statement.ActualElapsedMs <= 0
                ? 0
                : statement.UdfElapsedMs / statement.ActualElapsedMs * 100;

            var functionOperators = operators
                .Where(x => !string.IsNullOrWhiteSpace(x.FunctionNames))
                .ToList();

            foreach (var name in names)
            {
                var matching = functionOperators
                    .Where(x => Contains(x.FunctionNames, name))
                    .OrderByDescending(x => x.ActualExecutions)
                    .ThenByDescending(x => x.ActualLogicalReads)
                    .ToList();

                var representative = matching.FirstOrDefault();
                var callText = ExtractFunctionCall(statement.StatementText, name);

                var calls = representative == null ? 0 :
                    Math.Max(representative.ActualExecutions, 0);

                var reads = representative == null ? 0 :
                    representative.ActualLogicalReads;

                var independentlyTimed = representative != null &&
                                         representative.ActualElapsedMs > 0 &&
                                         representative.ActualElapsedMs <
                                         statement.ActualElapsedMs * 0.98;

                var elapsed = independentlyTimed
                    ? representative.ActualElapsedMs
                    : 0;

                var cpu = independentlyTimed
                    ? representative.ActualCpuMs
                    : 0;

                var primary = udfShare >= 50 &&
                    (calls >= 1000 ||
                     (representative != null &&
                      representative.ActualLogicalReads >= 10000));

                report.ComponentFindings.Add(new StatementComponentFinding
                {
                    StatementId = statement.StatementId,
                    ComponentKind = ComponentKind.ScalarUdf,
                    ComponentName = name,
                    SqlText = callText,
                    StartLine = FindLine(statement, callText),
                    EndLine = FindLine(statement, callText),
                    NodeId = representative == null ? -1 : representative.NodeId,
                    Executions = calls,
                    ElapsedMs = elapsed,
                    CpuMs = cpu,
                    LogicalReads = reads,
                    TimingStatus = independentlyTimed
                        ? "Measured for the associated function operator"
                        : $"Per-function time is not isolated. Statement aggregate UDF time is " +
                          $"{FormatDuration(statement.UdfElapsedMs)} elapsed and " +
                          $"{FormatDuration(statement.UdfCpuMs)} CPU.",
                    Status = primary ? "Critical" :
                        udfShare >= 25 ? "High" : "Review",
                    Issue = primary
                        ? $"Scalar UDF {name} is strongly implicated in the slowdown."
                        : $"Scalar UDF {name} is called by this statement.",
                    Evidence = $"Statement UDF share {udfShare:N1}%; operator calls " +
                               $"{calls:N0}; operator logical reads {reads:N0}; " +
                               $"statement UDF elapsed {statement.UdfElapsedMs:N0} ms.",
                    FixLocation = BuildSourceLocation(statement, callText,
                        $"function call {name}"),
                    RecommendedFix =
                        "Reduce rows before this function is evaluated. Review an inline or " +
                        "set-based rewrite and avoid repeated row-by-row scalar execution.",
                    IsPrimaryCause = primary
                });
            }

            if (names.Count == 0 && statement.UdfElapsedMs > 0)
            {
                report.ComponentFindings.Add(new StatementComponentFinding
                {
                    StatementId = statement.StatementId,
                    ComponentKind = ComponentKind.ScalarUdf,
                    ComponentName = "Unidentified scalar UDFs",
                    SqlText = null,
                    StartLine = statement.ProcedureStartLine,
                    EndLine = statement.ProcedureEndLine,
                    Executions = 0,
                    ElapsedMs = 0,
                    CpuMs = 0,
                    TimingStatus = $"Aggregate UDF time only: " +
                                   $"{FormatDuration(statement.UdfElapsedMs)} elapsed, " +
                                   $"{FormatDuration(statement.UdfCpuMs)} CPU.",
                    Status = udfShare >= 50 ? "Critical" : "High",
                    Issue = "The plan records significant scalar UDF time but does not expose individual names.",
                    Evidence = $"UDF share of statement elapsed: {udfShare:N1}%.",
                    FixLocation = BuildSourceLocation(statement, null,
                        "all scalar function expressions"),
                    RecommendedFix = "Supply the exact stored-procedure source and review every scalar UDF call in this statement.",
                    IsPrimaryCause = udfShare >= 50
                });
            }
        }

        private static void AddSortAndSpillFindings(
            AnalysisReport report,
            StatementMetrics statement,
            List<OperatorMetrics> operators)
        {
            var sorts = operators
                .Where(x => Contains(x.PhysicalOperation, "Sort"))
                .ToList();

            if (sorts.Count == 0)
                return;

            var spilled = sorts.Where(x => x.HasSpill).ToList();
            var representative = sorts
                .OrderByDescending(x => x.ActualElapsedMs)
                .First();

            var clause = ExtractClause(
                statement.StatementText,
                @"\bORDER\s+BY\b[\s\S]*$");

            var isRoot = representative.NodeId == 0;
            var issue = spilled.Count > 0
                ? $"Sort spilled to TempDB at {spilled.Count} operator(s)."
                : "Sort operator is present.";

            report.ComponentFindings.Add(new StatementComponentFinding
            {
                StatementId = statement.StatementId,
                ComponentKind = spilled.Count > 0
                    ? ComponentKind.Spill
                    : ComponentKind.Sort,
                ComponentName = "Sort / ORDER BY",
                SqlText = clause,
                StartLine = FindLine(statement, clause),
                EndLine = FindLine(statement, clause),
                NodeId = representative.NodeId,
                Executions = representative.ActualExecutions,
                ElapsedMs = isRoot ? 0 : representative.ActualElapsedMs,
                CpuMs = isRoot ? 0 : representative.ActualCpuMs,
                LogicalReads = representative.ActualLogicalReads,
                TimingStatus = isRoot
                    ? "Root Sort timing overlaps the entire statement pipeline and is not treated as independent sort time."
                    : "Operator timing captured.",
                Status = spilled.Count > 0 ? "High" : "Review",
                Issue = issue,
                Evidence = $"Node {representative.NodeId}; spill count {spilled.Count}; " +
                           $"estimated rows {representative.EstimatedRows:N0}; actual rows " +
                           $"{representative.ActualRows:N0}.",
                FixLocation = BuildSourceLocation(statement, clause,
                    "ORDER BY / sorting requirement"),
                RecommendedFix =
                    "Correct row estimates and reduce rows before sorting; check whether an " +
                    "index can provide the required order. Re-test the memory grant and spill.",
                IsPrimaryCause = false
            });
        }

        private static void AddFilterFinding(
            AnalysisReport report,
            StatementMetrics statement,
            List<OperatorMetrics> operators)
        {
            var problematic = operators
                .Where(x => IsStorageAccess(x) &&
                            x.ActualRows > 0 &&
                            x.ActualRowsRead > x.ActualRows * 20)
                .OrderByDescending(x =>
                    x.ActualRowsRead / Math.Max(1, x.ActualRows))
                .FirstOrDefault();

            if (problematic == null)
                return;

            var where = ExtractClause(
                statement.StatementText,
                @"\bWHERE\b[\s\S]*?(?=\bGROUP\s+BY\b|\bORDER\s+BY\b|$)");

            report.ComponentFindings.Add(new StatementComponentFinding
            {
                StatementId = statement.StatementId,
                ComponentKind = ComponentKind.Filter,
                ComponentName = "WHERE filtering",
                SqlText = where,
                StartLine = FindLine(statement, where),
                EndLine = FindLine(statement, where),
                NodeId = problematic.NodeId,
                Executions = problematic.ActualExecutions,
                ElapsedMs = 0,
                CpuMs = 0,
                LogicalReads = problematic.ActualLogicalReads,
                TimingStatus =
                    "Filter time is included in the parent statement and is not independently isolated.",
                Status = "High",
                Issue = $"Filtering read {problematic.ActualRowsRead:N0} rows to return " +
                        $"{problematic.ActualRows:N0}.",
                Evidence = $"Object {problematic.ObjectName}; index " +
                           $"{problematic.IndexName}; predicate {problematic.Predicate}.",
                FixLocation = BuildSourceLocation(statement, where,
                    "WHERE filtering clause"),
                RecommendedFix =
                    "Rewrite non-SARGable predicates, improve selectivity and review index key order.",
                IsPrimaryCause = false
            });
        }

        private static void AddLookupFindings(
            AnalysisReport report,
            StatementMetrics statement,
            List<OperatorMetrics> operators)
        {
            foreach (var lookup in operators
                .Where(x => Contains(x.PhysicalOperation, "Lookup") &&
                            x.ActualExecutions >= 100)
                .GroupBy(x => (x.ObjectName ?? "") + "|" + (x.IndexName ?? ""))
                .Select(x => x.OrderByDescending(y => y.ActualExecutions).First()))
            {
                report.ComponentFindings.Add(new StatementComponentFinding
                {
                    StatementId = statement.StatementId,
                    ComponentKind = ComponentKind.Lookup,
                    ComponentName = $"Lookup: {lookup.ObjectName}",
                    SqlText = statement.StatementText,
                    StartLine = statement.ProcedureStartLine,
                    EndLine = statement.ProcedureEndLine,
                    NodeId = lookup.NodeId,
                    Executions = lookup.ActualExecutions,
                    ElapsedMs = lookup.ActualElapsedMs,
                    CpuMs = lookup.ActualCpuMs,
                    LogicalReads = lookup.ActualLogicalReads,
                    TimingStatus = "Lookup operator counters captured.",
                    Status = lookup.ActualExecutions >= 10000 ? "High" : "Review",
                    Issue = $"Repeated lookup executed {lookup.ActualExecutions:N0} times.",
                    Evidence = $"Object {lookup.ObjectName}; index {lookup.IndexName}; " +
                               $"rows {lookup.ActualRows:N0}; reads {lookup.ActualLogicalReads:N0}.",
                    FixLocation = BuildSourceLocation(statement, null,
                        $"SELECT columns requiring lookup on {lookup.ObjectName}"),
                    RecommendedFix =
                        "Review whether a covering index or fewer selected columns can remove the lookup.",
                    IsPrimaryCause = false
                });
            }
        }

        private static void AddJoinFindings(
            AnalysisReport report,
            StatementMetrics statement,
            List<OperatorMetrics> operators)
        {
            var joins = operators
                .Where(x => Contains(x.LogicalOperation, "Join") ||
                            Contains(x.LogicalOperation, "Apply"))
                .Where(x => Ratio(x.EstimatedRows, x.ActualRows) >= 100)
                .OrderByDescending(x => Ratio(x.EstimatedRows, x.ActualRows))
                .Take(3)
                .ToList();

            foreach (var join in joins)
            {
                var joinText = ExtractClause(
                    statement.StatementText,
                    @"(?:(?:INNER|LEFT|RIGHT|FULL|CROSS)\s+)?JOIN\b[\s\S]*?\bON\b[\s\S]*?(?=\b(?:INNER|LEFT|RIGHT|FULL|CROSS)\s+JOIN\b|\bWHERE\b|\bGROUP\s+BY\b|\bORDER\s+BY\b|$)");

                report.ComponentFindings.Add(new StatementComponentFinding
                {
                    StatementId = statement.StatementId,
                    ComponentKind = ComponentKind.Join,
                    ComponentName = $"{join.PhysicalOperation} join",
                    SqlText = joinText,
                    StartLine = FindLine(statement, joinText),
                    EndLine = FindLine(statement, joinText),
                    NodeId = join.NodeId,
                    Executions = join.ActualExecutions,
                    ElapsedMs = join.ActualElapsedMs,
                    CpuMs = join.ActualCpuMs,
                    LogicalReads = join.ActualLogicalReads,
                    TimingStatus = "Join operator counters captured.",
                    Status = "High",
                    Issue = $"Join cardinality mismatch is " +
                            $"{Ratio(join.EstimatedRows, join.ActualRows):N1}x.",
                    Evidence = $"Estimated rows {join.EstimatedRows:N0}; actual rows " +
                               $"{join.ActualRows:N0}.",
                    FixLocation = BuildSourceLocation(statement, joinText,
                        "JOIN and ON clause"),
                    RecommendedFix =
                        "Review join predicates, statistics, parameter sensitivity and data skew.",
                    IsPrimaryCause = false
                });
            }
        }

        private static string ExtractClause(string sql, string pattern)
        {
            if (string.IsNullOrWhiteSpace(sql))
                return null;

            var match = Regex.Match(sql, pattern,
                RegexOptions.IgnoreCase | RegexOptions.Multiline);

            return match.Success ? match.Value.Trim() : null;
        }

        private static string ExtractFunctionCall(string sql, string name)
        {
            if (string.IsNullOrWhiteSpace(sql) || string.IsNullOrWhiteSpace(name))
                return null;

            var start = sql.IndexOf(name, StringComparison.OrdinalIgnoreCase);
            if (start < 0)
            {
                var shortName = name.Contains(".")
                    ? name.Substring(name.LastIndexOf('.') + 1)
                    : name;
                start = sql.IndexOf(shortName, StringComparison.OrdinalIgnoreCase);
            }

            if (start < 0)
                return null;

            var open = sql.IndexOf('(', start);
            if (open < 0)
                return null;

            var depth = 0;
            var inString = false;
            for (var i = open; i < sql.Length; i++)
            {
                if (sql[i] == '\'' && (i == 0 || sql[i - 1] != '\\'))
                    inString = !inString;

                if (inString) continue;

                if (sql[i] == '(') depth++;
                if (sql[i] == ')')
                {
                    depth--;
                    if (depth == 0)
                        return sql.Substring(start, i - start + 1);
                }
            }

            return null;
        }

        private static int? FindLine(StatementMetrics statement, string fragment)
        {
            if (!statement.ProcedureStartLine.HasValue ||
                string.IsNullOrWhiteSpace(fragment) ||
                string.IsNullOrWhiteSpace(statement.StatementText))
                return statement.ProcedureStartLine;

            var index = statement.StatementText.IndexOf(
                fragment, StringComparison.OrdinalIgnoreCase);

            if (index < 0)
                return statement.ProcedureStartLine;

            var offset = statement.StatementText
                .Substring(0, index)
                .Count(x => x == '\n');

            return statement.ProcedureStartLine.Value + offset;
        }

        private static string BuildSourceLocation(
            StatementMetrics statement,
            string fragment,
            string description)
        {
            var line = FindLine(statement, fragment);
            return line.HasValue
                ? $"Stored procedure line {line.Value}; {description}."
                : $"Statement {statement.StatementId}; {description}.";
        }

        private static IEnumerable<string> SplitNames(string value)
        {
            return (value ?? string.Empty)
                .Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(Clean)
                .Where(x => !string.IsNullOrWhiteSpace(x));
        }

        private static bool LooksLikeUserFunction(string name)
        {
            var lower = (name ?? string.Empty).ToLowerInvariant();
            return lower.Contains(".f_") ||
                   lower.Contains(".fn_") ||
                   lower.StartsWith("dbo.");
        }

        private static string Clean(string value) =>
            (value ?? string.Empty).Replace("[", "").Replace("]", "").Trim();

        private static bool Contains(string value, string token) =>
            (value ?? string.Empty).IndexOf(
                token ?? string.Empty,
                StringComparison.OrdinalIgnoreCase) >= 0;

        private static bool IsStorageAccess(OperatorMetrics op) =>
            Contains(op.PhysicalOperation, "Scan") ||
            Contains(op.PhysicalOperation, "Seek") ||
            Contains(op.PhysicalOperation, "Lookup");

        private static double Ratio(double estimated, double actual)
        {
            if (estimated <= 0 || actual <= 0) return 0;
            return Math.Max(estimated / actual, actual / estimated);
        }

        private static string FormatDuration(double milliseconds) =>
            milliseconds >= 1000
                ? $"{milliseconds / 1000.0:N3} sec"
                : $"{milliseconds:N1} ms";
    }
}
