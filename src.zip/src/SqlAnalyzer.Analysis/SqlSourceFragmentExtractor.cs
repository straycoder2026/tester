using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using SqlAnalyzer.Core;

namespace SqlAnalyzer.Analysis
{
    public sealed class SqlSourceFragmentExtractor
    {
        private static readonly Regex UdfRegex = new Regex(
            @"(?<name>(?:\[[^\]]+\]|\w+)\.(?:\[[^\]]+\]|\w+))\s*\(",
            RegexOptions.IgnoreCase | RegexOptions.Compiled);

        public void Extract(AnalysisReport report, string procedureFile)
        {
            if (string.IsNullOrWhiteSpace(procedureFile) ||
                !System.IO.File.Exists(procedureFile))
                return;

            var lines = System.IO.File.ReadAllLines(procedureFile);

            foreach (var statement in report.Statements)
            {
                if (!statement.ProcedureStartLine.HasValue)
                    continue;

                var start = Math.Max(1, statement.ProcedureStartLine.Value);
                var end = Math.Min(
                    lines.Length,
                    statement.ProcedureEndLine ?? statement.ProcedureStartLine.Value);

                // Expand the source range to include the complete statement when the mapper
                // matched only its first line.
                end = ExpandStatementEnd(lines, start, end);

                var fullText = JoinLines(lines, start, end);
                Add(report, statement.StatementId, SourceFragmentType.FullStatement,
                    start, end, fullText, "Full SQL statement",
                    "Parent statement context");

                ExtractClauses(report, statement.StatementId, lines, start, end);
                ExtractSubqueries(report, statement.StatementId, lines, start, end);
                ExtractUdfCalls(report, statement.StatementId, lines, start, end);
            }
        }

        private static void ExtractClauses(
            AnalysisReport report,
            int statementId,
            string[] lines,
            int start,
            int end)
        {
            ExtractClause(report, statementId, lines, start, end,
                @"^\s*WHERE\b", SourceFragmentType.FilteringClause,
                "Filtering clause", new[] { "GROUP BY", "ORDER BY", "OPTION", "FOR XML", "UNION" });

            ExtractClause(report, statementId, lines, start, end,
                @"^\s*(INNER|LEFT|RIGHT|FULL|CROSS)?\s*JOIN\b",
                SourceFragmentType.JoinClause,
                "Join clause", new[] { "INNER JOIN", "LEFT JOIN", "RIGHT JOIN",
                    "FULL JOIN", "CROSS JOIN", "WHERE", "GROUP BY", "ORDER BY" });

            ExtractClause(report, statementId, lines, start, end,
                @"^\s*ORDER\s+BY\b", SourceFragmentType.SortClause,
                "Ordering clause", new[] { "OPTION", "FOR XML", "UNION" });

            ExtractClause(report, statementId, lines, start, end,
                @"^\s*GROUP\s+BY\b", SourceFragmentType.GroupingClause,
                "Grouping clause", new[] { "HAVING", "ORDER BY", "OPTION", "FOR XML" });
        }

        private static void ExtractClause(
            AnalysisReport report,
            int statementId,
            string[] lines,
            int statementStart,
            int statementEnd,
            string startPattern,
            SourceFragmentType type,
            string displayName,
            string[] stopKeywords)
        {
            for (var lineNumber = statementStart; lineNumber <= statementEnd; lineNumber++)
            {
                if (!Regex.IsMatch(lines[lineNumber - 1], startPattern,
                    RegexOptions.IgnoreCase))
                    continue;

                var end = lineNumber;
                for (var scan = lineNumber + 1; scan <= statementEnd; scan++)
                {
                    var trimmed = lines[scan - 1].TrimStart();
                    if (stopKeywords.Any(x =>
                        trimmed.StartsWith(x, StringComparison.OrdinalIgnoreCase)))
                        break;

                    end = scan;
                }

                Add(report, statementId, type, lineNumber, end,
                    JoinLines(lines, lineNumber, end), displayName,
                    $"Mapped from {displayName.ToLowerInvariant()} source syntax");
            }
        }

        private static void ExtractSubqueries(
            AnalysisReport report,
            int statementId,
            string[] lines,
            int start,
            int end)
        {
            var text = JoinLines(lines, start, end);
            var offsets = FindNestedSelectOffsets(text);

            foreach (var offset in offsets)
            {
                var fragment = ExtractBalancedSubquery(text, offset);
                if (string.IsNullOrWhiteSpace(fragment))
                    continue;

                var relativeLine = CountLines(text.Substring(0, offset));
                var subStart = start + relativeLine;
                var subEnd = subStart + CountLines(fragment);

                var correlated = Regex.IsMatch(
                    fragment,
                    @"\b(?:WHERE|ON)\b[\s\S]*\b\w+\.\w+\s*=\s*\w+\.\w+",
                    RegexOptions.IgnoreCase);

                var lookup = Regex.IsMatch(
                    fragment,
                    @"\bWHERE\b[\s\S]*\b(?:ID|KEY|CODE)\b\s*=",
                    RegexOptions.IgnoreCase);

                var type = correlated
                    ? SourceFragmentType.CorrelatedSubquery
                    : lookup
                        ? SourceFragmentType.LookupSubquery
                        : SourceFragmentType.ScalarSubquery;

                var name = correlated
                    ? "Correlated subquery"
                    : lookup
                        ? "Lookup subquery"
                        : "Nested subquery";

                Add(report, statementId, type, subStart, subEnd,
                    fragment.Trim(), name,
                    "Detected as nested SELECT inside the parent statement");
            }
        }

        private static void ExtractUdfCalls(
            AnalysisReport report,
            int statementId,
            string[] lines,
            int start,
            int end)
        {
            var text = JoinLines(lines, start, end);

            foreach (Match match in UdfRegex.Matches(text))
            {
                var name = CleanName(match.Groups["name"].Value);

                // Skip common built-in functions and aliases that look schema-qualified.
                if (IsBuiltIn(name))
                    continue;

                var call = ExtractFunctionCall(text, match.Index);
                if (string.IsNullOrWhiteSpace(call))
                    continue;

                var relativeStart = CountLines(text.Substring(0, match.Index));
                var relativeEnd = relativeStart + CountLines(call);

                Add(report, statementId, SourceFragmentType.UdfCall,
                    start + relativeStart,
                    start + relativeEnd,
                    call.Trim(),
                    $"Scalar UDF: {name}",
                    "Detected from schema-qualified function call",
                    name);
            }
        }

        private static int ExpandStatementEnd(
            string[] lines,
            int start,
            int currentEnd)
        {
            var depth = 0;
            var foundKeyword = false;
            var end = currentEnd;

            for (var lineNumber = start;
                 lineNumber <= Math.Min(lines.Length, start + 250);
                 lineNumber++)
            {
                var line = RemoveComments(lines[lineNumber - 1]);

                if (Regex.IsMatch(line, @"\b(SELECT|INSERT|UPDATE|DELETE|MERGE)\b",
                    RegexOptions.IgnoreCase))
                    foundKeyword = true;

                depth += line.Count(x => x == '(');
                depth -= line.Count(x => x == ')');
                end = lineNumber;

                if (foundKeyword && depth <= 0 &&
                    (line.TrimEnd().EndsWith(";") ||
                     Regex.IsMatch(line, @"^\s*END\b", RegexOptions.IgnoreCase)))
                    break;
            }

            return Math.Max(currentEnd, end);
        }

        private static List<int> FindNestedSelectOffsets(string text)
        {
            var results = new List<int>();
            foreach (Match match in Regex.Matches(
                text,
                @"\(\s*SELECT\b",
                RegexOptions.IgnoreCase))
            {
                results.Add(match.Index);
            }

            return results;
        }

        private static string ExtractBalancedSubquery(
            string text,
            int openingParenthesis)
        {
            var depth = 0;
            var inString = false;

            for (var index = openingParenthesis; index < text.Length; index++)
            {
                var character = text[index];

                if (character == '\'' &&
                    (index == 0 || text[index - 1] != '\\'))
                    inString = !inString;

                if (inString)
                    continue;

                if (character == '(')
                    depth++;
                else if (character == ')')
                {
                    depth--;
                    if (depth == 0)
                        return text.Substring(
                            openingParenthesis,
                            index - openingParenthesis + 1);
                }
            }

            return null;
        }

        private static string ExtractFunctionCall(
            string text,
            int functionStart)
        {
            var open = text.IndexOf('(', functionStart);
            if (open < 0)
                return null;

            var depth = 0;
            var inString = false;

            for (var index = open; index < text.Length; index++)
            {
                var character = text[index];

                if (character == '\'' &&
                    (index == 0 || text[index - 1] != '\\'))
                    inString = !inString;

                if (inString)
                    continue;

                if (character == '(')
                    depth++;
                else if (character == ')')
                {
                    depth--;
                    if (depth == 0)
                        return text.Substring(
                            functionStart,
                            index - functionStart + 1);
                }
            }

            return null;
        }

        private static void Add(
            AnalysisReport report,
            int statementId,
            SourceFragmentType type,
            int start,
            int end,
            string sql,
            string displayName,
            string reason,
            string functionName = null)
        {
            if (string.IsNullOrWhiteSpace(sql))
                return;

            var duplicate = report.SourceFragments.Any(x =>
                x.StatementId == statementId &&
                x.FragmentType == type &&
                x.StartLine == start &&
                string.Equals(x.SqlText, sql, StringComparison.Ordinal));

            if (duplicate)
                return;

            report.SourceFragments.Add(new SourceFragment
            {
                StatementId = statementId,
                FragmentType = type,
                StartLine = start,
                EndLine = end,
                SqlText = sql.Trim(),
                DisplayName = displayName,
                Status = "Detected",
                MappingReason = reason,
                RelatedFunctionName = functionName
            });
        }

        private static string JoinLines(
            string[] lines,
            int start,
            int end)
        {
            var builder = new StringBuilder();

            for (var line = start; line <= end && line <= lines.Length; line++)
            {
                if (builder.Length > 0)
                    builder.AppendLine();

                builder.Append(lines[line - 1]);
            }

            return builder.ToString();
        }

        private static int CountLines(string value)
        {
            if (string.IsNullOrEmpty(value))
                return 0;

            return value.Count(x => x == '\n');
        }

        private static string CleanName(string value)
        {
            return (value ?? string.Empty)
                .Replace("[", string.Empty)
                .Replace("]", string.Empty);
        }

        private static bool IsBuiltIn(string name)
        {
            var lower = (name ?? string.Empty).ToLowerInvariant();

            return lower.StartsWith("sys.") ||
                   lower.Contains("string.") ||
                   lower.EndsWith(".value") ||
                   lower.EndsWith(".query") ||
                   lower.EndsWith(".nodes");
        }

        private static string RemoveComments(string line)
        {
            var index = line.IndexOf("--", StringComparison.Ordinal);
            return index < 0 ? line : line.Substring(0, index);
        }
    }
}
