@echo off
start "" "%~dp0SqlAnalyzer.sln"
