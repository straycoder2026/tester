using System;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;
using SqlAnalyzer.Analysis;
using SqlAnalyzer.Reporting;

namespace SqlAnalyzer.Desktop
{
    public sealed class MainForm : Form
    {
        private readonly TextBox _plan = NewTextBox();
        private readonly TextBox _procedure = NewTextBox();
        private readonly TextBox _beforePlan = NewTextBox();
        private readonly TextBox _beforeProcedure = NewTextBox();
        private readonly TextBox _afterPlan = NewTextBox();
        private readonly TextBox _afterProcedure = NewTextBox();
        private readonly TextBox _output = NewTextBox();

        public MainForm()
        {
            Text = "SQL Analyzer";
            Width = 1000;
            Height = 680;
            StartPosition = FormStartPosition.CenterScreen;

            var tabs = new TabControl { Dock = DockStyle.Fill };
            tabs.TabPages.Add(BuildAnalyzeTab());
            tabs.TabPages.Add(BuildCompareTab());
            Controls.Add(tabs);
        }

        private TabPage BuildAnalyzeTab()
        {
            var page = new TabPage("Analyze Plan / Procedure");
            var panel = NewPanel();

            AddFileRow(panel, 20, "Execution plan (.sqlplan):", _plan,
                () => Browse(_plan, "SQL execution plan|*.sqlplan|XML file|*.xml"));
            AddFileRow(panel, 75, "Stored procedure (.sql, optional):", _procedure,
                () => Browse(_procedure, "SQL source|*.sql|Text file|*.txt"));
            AddFileRow(panel, 130, "Output report (.html):", _output,
                () => Save(_output, "HTML report|*.html"));

            panel.Controls.Add(new Label
            {
                Left = 20,
                Top = 190,
                Width = 880,
                Height = 70,
                Text = "Plan-only analysis is supported. Add the stored procedure to enable " +
                       "source-line mapping and static SQL checks. Actual time is available " +
                       "only from an actual execution plan."
            });

            var button = new Button
            {
                Left = 20,
                Top = 275,
                Width = 190,
                Height = 38,
                Text = "Generate Analysis Report"
            };
            button.Click += AnalyzeClick;
            panel.Controls.Add(button);

            page.Controls.Add(panel);
            return page;
        }

        private TabPage BuildCompareTab()
        {
            var page = new TabPage("Compare Before / After");
            var panel = NewPanel();

            AddFileRow(panel, 20, "Before plan:", _beforePlan,
                () => Browse(_beforePlan, "SQL execution plan|*.sqlplan|XML file|*.xml"));
            AddFileRow(panel, 75, "Before procedure (optional):", _beforeProcedure,
                () => Browse(_beforeProcedure, "SQL source|*.sql|Text file|*.txt"));
            AddFileRow(panel, 130, "After plan:", _afterPlan,
                () => Browse(_afterPlan, "SQL execution plan|*.sqlplan|XML file|*.xml"));
            AddFileRow(panel, 185, "After procedure (optional):", _afterProcedure,
                () => Browse(_afterProcedure, "SQL source|*.sql|Text file|*.txt"));

            var button = new Button
            {
                Left = 20,
                Top = 255,
                Width = 225,
                Height = 38,
                Text = "Generate Diagnostic Comparison"
            };
            button.Click += CompareClick;
            panel.Controls.Add(button);

            panel.Controls.Add(new Label
            {
                Left = 20,
                Top = 315,
                Width = 880,
                Height = 100,
                Text = "The tool creates separate Before Detailed, After Detailed, and " +
                       "Comparison reports. The comparison report lists improvements, " +
                       "regressions, new issues, resolved issues, and an executive summary."
            });

            page.Controls.Add(panel);
            return page;
        }

        private void AnalyzeClick(object sender, EventArgs e)
        {
            try
            {
                RequireFile(_plan.Text, "Select an execution plan.");

                if (string.IsNullOrWhiteSpace(_output.Text))
                {
                    _output.Text = Path.Combine(
                        Path.GetDirectoryName(_plan.Text),
                        Path.GetFileNameWithoutExtension(_plan.Text) +
                        "_SqlAnalyzer_Report.html");
                }

                var report = new AnalysisService().Analyze(
                    Path.GetFileNameWithoutExtension(_plan.Text),
                    _plan.Text,
                    EmptyToNull(_procedure.Text));

                new AnalysisReportWriter().Write(report, _output.Text);
                OpenReport(_output.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "SQL Analyzer",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CompareClick(object sender, EventArgs e)
        {
            try
            {
                RequireFile(_beforePlan.Text, "Select the before execution plan.");
                RequireFile(_afterPlan.Text, "Select the after execution plan.");

                using (var dialog = new FolderBrowserDialog())
                {
                    dialog.Description = "Select output folder for the three reports.";

                    if (dialog.ShowDialog(this) != DialogResult.OK)
                    {
                        return;
                    }

                    var service = new AnalysisService();
                    var before = service.Analyze(
                        "Before",
                        _beforePlan.Text,
                        EmptyToNull(_beforeProcedure.Text));
                    var after = service.Analyze(
                        "After",
                        _afterPlan.Text,
                        EmptyToNull(_afterProcedure.Text));

                    var beforeFile = Path.Combine(
                        dialog.SelectedPath,
                        "01_Before_Detailed_Report.html");
                    var afterFile = Path.Combine(
                        dialog.SelectedPath,
                        "02_After_Detailed_Report.html");
                    var comparisonFile = Path.Combine(
                        dialog.SelectedPath,
                        "03_Diagnostic_Comparison_Report.html");

                    var detailed = new AnalysisReportWriter();
                    detailed.Write(before, beforeFile);
                    detailed.Write(after, afterFile);

                    var comparison = new ComparisonService().Compare(before, after);
                    new ComparisonReportWriter().Write(comparison, comparisonFile);

                    OpenReport(comparisonFile);

                    var generatedFiles =
                        "Three reports were generated:" +
                        Environment.NewLine + Environment.NewLine +
                        beforeFile + Environment.NewLine +
                        afterFile + Environment.NewLine +
                        comparisonFile;

                    MessageBox.Show(generatedFiles, "SQL Analyzer",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "SQL Analyzer",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private static Panel NewPanel()
        {
            return new Panel { Dock = DockStyle.Fill, AutoScroll = true };
        }

        private static TextBox NewTextBox()
        {
            return new TextBox { Width = 650 };
        }

        private static void AddFileRow(
            Control parent,
            int top,
            string label,
            TextBox textBox,
            Action browse)
        {
            var lbl = new Label
            {
                Left = 20,
                Top = top + 4,
                Width = 205,
                Text = label
            };

            textBox.Left = 230;
            textBox.Top = top;

            var button = new Button
            {
                Left = 890,
                Top = top - 1,
                Width = 70,
                Height = 26,
                Text = "Browse"
            };
            button.Click += (sender, args) => browse();

            parent.Controls.Add(lbl);
            parent.Controls.Add(textBox);
            parent.Controls.Add(button);
        }

        private void Browse(TextBox target, string filter)
        {
            using (var dialog = new OpenFileDialog { Filter = filter })
            {
                if (dialog.ShowDialog(this) == DialogResult.OK)
                {
                    target.Text = dialog.FileName;
                }
            }
        }

        private void Save(TextBox target, string filter)
        {
            using (var dialog = new SaveFileDialog
            {
                Filter = filter,
                DefaultExt = "html"
            })
            {
                if (dialog.ShowDialog(this) == DialogResult.OK)
                {
                    target.Text = dialog.FileName;
                }
            }
        }

        private static string EmptyToNull(string value)
        {
            return string.IsNullOrWhiteSpace(value) ? null : value;
        }

        private static void RequireFile(string path, string message)
        {
            if (string.IsNullOrWhiteSpace(path) || !File.Exists(path))
            {
                throw new FileNotFoundException(message, path);
            }
        }

        private static void OpenReport(string path)
        {
            Process.Start(new ProcessStartInfo
            {
                FileName = path,
                UseShellExecute = true
            });
        }
    }
}
