using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using SqlAnalyzer.Core;

namespace SqlAnalyzer.Reporting
{
    public sealed class AnalysisReportWriter
    {
        public void Write(AnalysisReport report, string outputFile)
        {
            var html = new StringBuilder();
            html.Append(HtmlUtility.PageStart("SQL Analyzer Report"));
            html.Append("<h1>SQL Analyzer – Performance and Bottleneck Assessment</h1>");
            html.Append($"<div class='subtitle'>{HtmlUtility.Encode(report.ReportName)} | " +
                        $"{report.PlanKind} plan | Generated {report.GeneratedUtc:u}</div>");

            WriteExecutiveSummary(html, report);
            WriteCapturedTimingTruth(html, report);
            WriteStatementResourceRanking(html, report);
            WriteDominantRuntimeDrivers(html, report);
            WriteExecutiveStatementTable(html, report);
            WriteExecutiveDecisionMatrix(html, report);
            WriteRootCauseByStatement(html, report);
            WriteSourceFocusedIssueLocations(html, report);
            WriteDetailedStatementFindings(html, report);
            WriteStaticIssues(html, report);
            WriteStatementSummary(html, report);
            WriteOperatorDetail(html, report);
            WriteLimitations(html, report);

            html.Append(HtmlUtility.PageEnd);
            File.WriteAllText(outputFile, html.ToString(), Encoding.UTF8);
        }

        private static void WriteExecutiveSummary(
            StringBuilder html,
            AnalysisReport report)
        {
            var critical = report.PlanIssues.Count(x => x.Severity == Severity.Critical) +
                           report.StaticSqlIssues.Count(x => x.Severity == Severity.Critical);
            var high = report.PlanIssues.Count(x => x.Severity == Severity.High) +
                       report.StaticSqlIssues.Count(x => x.Severity == Severity.High);

            var affectedStatements = report.PlanIssues
                .Where(IsExecutiveIssue)
                .Select(x => x.StatementId)
                .Distinct()
                .Count();

            html.Append("<div class='card'><h2>Executive Summary</h2>");
            html.Append($"<div class='decision'>{HtmlUtility.Encode(report.ExecutiveDecision)}</div>");
            html.Append("<table><tr><th>Measure</th><th>Result</th></tr>");
            html.Append($"<tr><td>Overall score</td><td><b>{report.Score}/100</b></td></tr>");
            html.Append($"<tr><td>Critical issues</td><td><b>{critical}</b></td></tr>");
            html.Append($"<tr><td>High issues</td><td><b>{high}</b></td></tr>");
            html.Append($"<tr><td>Statements requiring executive attention</td><td><b>{affectedStatements}</b></td></tr>");
            html.Append($"<tr><td>Fix-now issues</td><td><b>{report.FixNowCount}</b></td></tr>");
            html.Append($"<tr><td>Planned fixes</td><td><b>{report.PlannedFixCount}</b></td></tr>");
            html.Append($"<tr><td>Plan type</td><td>{report.PlanKind}</td></tr>");
            html.Append("</table>");

            html.Append(report.PlanKind == PlanKind.Actual
                ? "<p>Runtime evidence is available where SQL Server recorded it.</p>"
                : "<p>This is an estimated plan. Actual elapsed time cannot be reported; estimated cost contribution is used instead.</p>");

            html.Append("</div>");
        }



        private static void WriteCapturedTimingTruth(
            StringBuilder html,
            AnalysisReport report)
        {
            html.Append("<h2>Captured Timing from the Execution Plan</h2>");
            html.Append("<p class='muted'>These values are read directly from each " +
                        "StmtSimple/QueryPlan/QueryTimeStats element. They are the timing " +
                        "values actually stored in this uploaded .sqlplan file.</p>");

            html.Append("<table><tr><th>Statement</th><th>Executions</th>" +
                        "<th>Elapsed</th><th>CPU</th><th>UDF elapsed</th>" +
                        "<th>UDF CPU</th><th>Timing source</th></tr>");

            foreach (var statement in report.Statements
                .OrderByDescending(x => x.ActualElapsedMs))
            {
                html.Append($"<tr><td><b>Statement {statement.StatementId}</b></td>" +
                            $"<td>{statement.ExecutionCount:N0}</td>" +
                            $"<td><b>{FormatDuration(statement.ActualElapsedMs)}</b></td>" +
                            $"<td><b>{FormatDuration(statement.ActualCpuMs)}</b></td>" +
                            $"<td>{FormatDuration(statement.UdfElapsedMs)}</td>" +
                            $"<td>{FormatDuration(statement.UdfCpuMs)}</td>" +
                            $"<td>{HtmlUtility.Encode(statement.TimingSource)}</td></tr>");
            }

            var totalElapsed = report.Statements.Sum(x => x.ActualElapsedMs);
            var totalCpu = report.Statements.Sum(x => x.ActualCpuMs);

            html.Append($"<tr class='good'><td><b>Sum of captured statements</b></td>" +
                        "<td>—</td>" +
                        $"<td><b>{FormatDuration(totalElapsed)}</b></td>" +
                        $"<td><b>{FormatDuration(totalCpu)}</b></td>" +
                        "<td colspan='3'>This sum is not a guaranteed stored-procedure wall-clock duration because statements and parallel CPU can overlap.</td></tr>");

            html.Append("</table>");
        }

        private static void WriteStatementResourceRanking(
            StringBuilder html,
            AnalysisReport report)
        {
            var statements = report.Statements
                .Select(statement => new
                {
                    Statement = statement,
                    IssueCount = report.PlanIssues.Count(x =>
                        x.StatementId == statement.StatementId),
                    CriticalHighCount = report.PlanIssues.Count(x =>
                        x.StatementId == statement.StatementId &&
                        (x.Severity == Severity.Critical ||
                         x.Severity == Severity.High)),
                    FixNowCount = report.PlanIssues.Count(x =>
                        x.StatementId == statement.StatementId &&
                        x.Priority == RemediationPriority.FixNow)
                })
                .ToList();

            var totalElapsed = statements.Sum(x => x.Statement.ActualElapsedMs);
            var totalCpu = statements.Sum(x => x.Statement.ActualCpuMs);
            var totalReads = statements.Sum(x => x.Statement.ActualLogicalReads);
            var totalCost = statements.Sum(x => x.Statement.EstimatedSubtreeCost);

            var ranked = statements
                .OrderByDescending(x =>
                    report.PlanKind == PlanKind.Actual &&
                    x.Statement.ActualElapsedMs > 0
                        ? x.Statement.ActualElapsedMs
                        : x.Statement.EstimatedSubtreeCost)
                .ToList();

            html.Append("<h2>Statement Resource Consumption Ranking</h2>");
            html.Append("<p class='muted'>This table identifies which SQL statement " +
                        "consumed the most elapsed time, CPU, logical reads and estimated " +
                        "optimizer cost. Statement-level metrics are preferred over node-level " +
                        "metrics for executive interpretation.</p>");

            html.Append("<table><tr><th>Rank</th><th>Statement / procedure line</th>" +
                        "<th>Executions</th><th>Elapsed time per captured execution</th><th>CPU</th><th>Logical reads</th>" +
                        "<th>Estimated cost</th><th>Resource assessment</th>" +
                        "<th>Critical / high issues</th></tr>");

            var rank = 0;
            foreach (var item in ranked)
            {
                rank++;
                var statement = item.Statement;
                var elapsedPct = Percentage(statement.ActualElapsedMs, totalElapsed);
                var cpuPct = Percentage(statement.ActualCpuMs, totalCpu);
                var readsPct = Percentage(statement.ActualLogicalReads, totalReads);
                var costPct = Percentage(statement.EstimatedSubtreeCost, totalCost);

                var assessment = ResourceAssessment(
                    report,
                    statement,
                    elapsedPct,
                    cpuPct,
                    readsPct,
                    costPct,
                    rank);

                var cssClass = rank == 1 ? "High" :
                    item.CriticalHighCount > 0 ? "Medium" : string.Empty;

                html.Append($"<tr class='{cssClass}'>");
                html.Append($"<td><b>#{rank}</b></td>");
                html.Append($"<td><b>Statement {statement.StatementId}</b><br>" +
                            (statement.ProcedureStartLine.HasValue
                                ? $"Procedure line {statement.ProcedureStartLine}<br>"
                                : "Procedure line not mapped.<br>") +
                            $"<code>{HtmlUtility.Encode(ShortText(statement.StatementText, 300))}</code></td>");

                html.Append($"<td><b>{statement.ExecutionCount:N0}</b></td>");

                html.Append(report.PlanKind == PlanKind.Actual
                    ? $"<td><b>{FormatDuration(statement.ActualElapsedMs)}</b><br>{elapsedPct:N1}% of captured statement elapsed time</td>"
                    : "<td>Not available in estimated plan</td>");

                html.Append(report.PlanKind == PlanKind.Actual
                    ? $"<td><b>{statement.ActualCpuMs:N1} ms</b><br>{cpuPct:N1}% of captured statement CPU</td>"
                    : "<td>Not available in estimated plan</td>");

                html.Append(report.PlanKind == PlanKind.Actual
                    ? $"<td><b>{statement.ActualLogicalReads:N0}</b><br>{readsPct:N1}% of captured logical reads</td>"
                    : "<td>Not available in estimated plan</td>");

                html.Append($"<td><b>{statement.EstimatedSubtreeCost:N4}</b><br>{costPct:N1}% of total statement cost</td>");
                html.Append($"<td>{HtmlUtility.Encode(assessment)}</td>");
                html.Append($"<td>{item.CriticalHighCount} critical/high; " +
                            $"{item.FixNowCount} fix-now; {item.IssueCount} total</td>");
                html.Append("</tr>");
            }

            if (ranked.Count == 0)
                html.Append("<tr><td colspan='9'>No SQL statements were found in the plan.</td></tr>");

            html.Append("</table>");

            if (ranked.Count > 0)
            {
                var top = ranked[0].Statement;
                html.Append("<div class='card'><h3>Primary Resource-Consuming Statement</h3>");
                html.Append($"<p><b>Statement {top.StatementId}</b> is ranked first. ");

                if (report.PlanKind == PlanKind.Actual && top.ActualElapsedMs > 0)
                {
                    html.Append($"It executed {top.ExecutionCount:N0} time(s) and consumed " +
                                $"{FormatDuration(top.ActualElapsedMs)} elapsed time, " +
                                $"{top.ActualCpuMs:N1} ms CPU and " +
                                $"{top.ActualLogicalReads:N0} logical reads in the captured execution.");
                }
                else
                {
                    html.Append($"Actual runtime was not available. It represents " +
                                $"{Percentage(top.EstimatedSubtreeCost, totalCost):N1}% " +
                                "of total estimated statement cost.");
                }

                html.Append("</p></div>");
            }
        }

        private static string ResourceAssessment(
            AnalysisReport report,
            StatementMetrics statement,
            double elapsedPercentage,
            double cpuPercentage,
            double readsPercentage,
            double costPercentage,
            int rank)
        {
            var observations = new List<string>();

            if (rank == 1)
                observations.Add("Highest overall resource-consuming statement.");

            if (report.PlanKind == PlanKind.Actual)
            {
                if (elapsedPercentage >= 50)
                    observations.Add("Dominates captured elapsed time.");
                else if (elapsedPercentage >= 25)
                    observations.Add("Major elapsed-time contributor.");

                if (cpuPercentage >= 50)
                    observations.Add("Dominates captured CPU consumption.");
                else if (cpuPercentage >= 25)
                    observations.Add("Major CPU contributor.");

                if (readsPercentage >= 50)
                    observations.Add("Dominates logical I/O.");
                else if (readsPercentage >= 25)
                    observations.Add("Major logical-read contributor.");
            }

            if (costPercentage >= 50)
                observations.Add("Dominates optimizer-estimated cost.");
            else if (costPercentage >= 25)
                observations.Add("Major optimizer-cost contributor.");

            if (observations.Count == 0)
                observations.Add("Resource use is distributed; review together with issue severity.");

            return string.Join(" ", observations);
        }

        private static double Percentage(
            double value,
            double total)
        {
            return total <= 0 ? 0 : value / total * 100;
        }

        private static double Percentage(
            long value,
            long total)
        {
            return total <= 0 ? 0 : (double)value / total * 100;
        }


        private static void WriteDominantRuntimeDrivers(
            StringBuilder html,
            AnalysisReport report)
        {
            if (report.PlanKind != PlanKind.Actual)
                return;

            var drivers = report.Statements
                .Select(statement => new
                {
                    Statement = statement,
                    Operator = report.Operators
                        .Where(x => x.StatementId == statement.StatementId)
                        .OrderByDescending(x => x.ActualElapsedMs)
                        .FirstOrDefault()
                })
                .Where(x => x.Operator != null &&
                            x.Operator.ActualElapsedMs > 0)
                .OrderByDescending(x => x.Operator.ActualElapsedMs)
                .Take(10)
                .ToList();

            html.Append("<h2>Dominant Runtime Drivers</h2>");
            html.Append("<p class='muted'>This table uses measured actual-plan runtime. " +
                        "It separates total statement duration from the operator/function " +
                        "that consumed most of that duration.</p>");
            html.Append("<table><tr><th>Statement</th><th>Statement execution</th>" +
                        "<th>Dominant operator / function</th><th>Driver time</th>" +
                        "<th>Executions</th><th>Logical reads</th>" +
                        "<th>Share of statement time</th></tr>");

            foreach (var item in drivers)
            {
                var statement = item.Statement;
                var op = item.Operator;
                var share = statement.ActualElapsedMs <= 0
                    ? 0
                    : op.ActualElapsedMs / statement.ActualElapsedMs * 100;

                var driver = op.NodeId == 0
                    ? op.PhysicalOperation + " (root pipeline timing; not isolated cause)"
                    : string.IsNullOrWhiteSpace(op.FunctionNames)
                        ? op.PhysicalOperation
                        : op.FunctionNames;

                html.Append("<tr>");
                html.Append($"<td><b>Statement {statement.StatementId}</b><br>" +
                            (statement.ProcedureStartLine.HasValue
                                ? $"Procedure line {statement.ProcedureStartLine}"
                                : "Procedure line not mapped") +
                            "</td>");
                html.Append($"<td>{statement.ExecutionCount:N0} execution(s)<br>" +
                            $"<b>{FormatDuration(statement.ActualElapsedMs)}</b> elapsed<br>" +
                            $"{FormatDuration(statement.ActualCpuMs)} CPU</td>");
                html.Append($"<td><b>{HtmlUtility.Encode(driver)}</b><br>" +
                            $"{HtmlUtility.Encode(op.PhysicalOperation)}; Node {op.NodeId}</td>");
                html.Append($"<td><b>{FormatDuration(op.ActualElapsedMs)}</b><br>" +
                            $"{FormatDuration(op.ActualCpuMs)} CPU</td>");
                html.Append($"<td>{op.ActualExecutions:N0}</td>");
                html.Append($"<td>{op.ActualLogicalReads:N0}</td>");
                html.Append($"<td>{share:N1}%</td></tr>");
            }

            if (drivers.Count == 0)
                html.Append("<tr><td colspan='7'>No operator runtime counters were available.</td></tr>");

            html.Append("</table>");
        }

        private static void WriteExecutiveStatementTable(
            StringBuilder html,
            AnalysisReport report)
        {
            var groups = report.PlanIssues
                .Where(IsExecutiveIssue)
                .GroupBy(x => x.StatementId)
                .Select(g => new StatementIssueGroup
                {
                    StatementId = g.Key,
                    Statement = report.Statements.FirstOrDefault(x => x.StatementId == g.Key),
                    Issues = g.OrderByDescending(x => x.Priority)
                              .ThenByDescending(x => x.Severity)
                              .ToList()
                })
                .OrderByDescending(x => x.HighestPriority)
                .ThenByDescending(x => x.HighestSeverity)
                .ToList();

            html.Append("<h2>Executive Critical and High Issues by SQL Statement</h2>");
            html.Append("<p class='muted'>One row represents one SQL statement. " +
                        "All related plan-node findings are consolidated below that statement " +
                        "so executives do not need to interpret multiple node rows.</p>");

            html.Append("<table><tr><th>Statement / procedure location</th>" +
                        "<th>Overall priority</th><th>Executions and statement time / cost</th>" +
                        "<th>Issues caused by this statement</th><th>Consolidated fix location</th>" +
                        "<th>Required action</th><th>Future risk</th></tr>");

            foreach (var group in groups)
            {
                var statement = group.Statement;
                var lineText = statement != null && statement.ProcedureStartLine.HasValue
                    ? $"Procedure lines {statement.ProcedureStartLine}" +
                      (statement.ProcedureEndLine.HasValue &&
                       statement.ProcedureEndLine != statement.ProcedureStartLine
                          ? $"-{statement.ProcedureEndLine}"
                          : string.Empty)
                    : "Procedure source not supplied or line not matched.";

                var css = group.HighestSeverity.ToString();

                html.Append($"<tr class='{css}'>");
                html.Append($"<td><b>Statement {group.StatementId}</b><br>{lineText}<br>" +
                            $"<code>{HtmlUtility.Encode(ShortText(statement == null ? null : statement.StatementText, 350))}</code></td>");
                html.Append($"<td><b>{group.HighestPriority}</b><br>{group.HighestSeverity}</td>");
                html.Append($"<td>{HtmlUtility.Encode(StatementImpact(report, group))}</td>");
                html.Append($"<td>{ConsolidatedIssueSummary(group.Issues)}</td>");
                html.Append($"<td>{HtmlUtility.Encode(ConsolidatedFixLocation(group))}</td>");
                html.Append($"<td>{HtmlUtility.Encode(ConsolidatedFix(group.Issues))}</td>");
                html.Append($"<td>{UniqueBulletList(group.Issues.Select(x => x.FutureRisk))}</td>");
                html.Append("</tr>");
            }

            var staticExecutive = report.StaticSqlIssues
                .Where(IsExecutiveIssue)
                .OrderByDescending(x => x.Priority)
                .ThenByDescending(x => x.Severity)
                .ToList();

            if (staticExecutive.Count > 0)
            {
                html.Append("<tr><td colspan='7'><b>High-priority stored-procedure source findings not reliably linked to one plan statement</b></td></tr>");
                foreach (var issue in staticExecutive)
                {
                    html.Append($"<tr class='{issue.Severity}'>");
                    html.Append($"<td><b>Stored procedure line {issue.LineNumber}</b><br>" +
                                $"<code>{HtmlUtility.Encode(issue.SourceLine)}</code></td>");
                    html.Append($"<td><b>{issue.Priority}</b><br>{issue.Severity}</td>");
                    html.Append("<td>Static source analysis; review the related statement plan for measured runtime.</td>");
                    html.Append($"<td><b>{HtmlUtility.Encode(issue.Issue)}</b></td>");
                    html.Append($"<td>{HtmlUtility.Encode(issue.FixLocation)}</td>");
                    html.Append($"<td>{HtmlUtility.Encode(issue.RecommendedFix)}</td>");
                    html.Append($"<td>{HtmlUtility.Encode(issue.FutureRisk)}</td></tr>");
                }
            }

            if (groups.Count == 0 && staticExecutive.Count == 0)
                html.Append("<tr><td colspan='7'>No Critical, High, or Fix-Now issues were detected.</td></tr>");

            html.Append("</table>");
        }

        private static void WriteExecutiveDecisionMatrix(
            StringBuilder html,
            AnalysisReport report)
        {
            html.Append("<h2>Executive Decision Matrix</h2>");
            html.Append("<table><tr><th>Condition</th><th>Decision</th><th>Owner</th></tr>");

            if (report.FixNowCount > 0)
            {
                html.Append("<tr class='Critical'><td>One or more Fix-Now issues exist</td>" +
                            "<td><b>Hold release and authorize immediate remediation</b></td>" +
                            "<td>Executive sponsor, DBA lead, development lead</td></tr>");
            }
            else if (report.PlannedFixCount > 0)
            {
                html.Append("<tr class='High'><td>No Fix-Now issue, but planned fixes exist</td>" +
                            "<td><b>Approve a dated remediation plan</b></td>" +
                            "<td>Development manager and DBA lead</td></tr>");
            }
            else
            {
                html.Append("<tr class='good'><td>No material remediation issue</td>" +
                            "<td><b>Proceed with monitoring</b></td>" +
                            "<td>Operations and DBA</td></tr>");
            }

            html.Append("</table>");
        }



        private static void WriteRootCauseByStatement(
            StringBuilder html,
            AnalysisReport report)
        {
            html.Append("<h2>What Exactly Is Causing the Slow Statement?</h2>");
            html.Append("<p class='muted'>This section distinguishes parent-statement " +
                        "time from UDF, filter, join, lookup, sort and spill evidence. " +
                        "Root operator timing is not automatically treated as causal " +
                        "because it can include the whole execution pipeline.</p>");

            var statementGroups = report.ComponentFindings
                .GroupBy(x => x.StatementId)
                .OrderByDescending(group =>
                    group.Where(x => x.ComponentKind == ComponentKind.ParentStatement)
                         .Select(x => x.ElapsedMs)
                         .FirstOrDefault())
                .ToList();

            foreach (var group in statementGroups)
            {
                var parent = group.FirstOrDefault(x =>
                    x.ComponentKind == ComponentKind.ParentStatement);

                if (parent == null)
                    continue;

                var components = group
                    .Where(x => x.ComponentKind != ComponentKind.ParentStatement)
                    .OrderByDescending(x => x.IsPrimaryCause)
                    .ThenBy(x => x.Status == "Critical" ? 0 :
                                 x.Status == "High" ? 1 : 2)
                    .ToList();

                html.Append("<div class='card'>");
                html.Append($"<h3>Statement {group.Key} — " +
                            $"{HtmlUtility.Encode(parent.Status)}</h3>");
                html.Append($"<p><b>Captured execution:</b> " +
                            $"{parent.Executions:N0} execution(s), " +
                            $"{FormatDuration(parent.ElapsedMs)} elapsed, " +
                            $"{FormatDuration(parent.CpuMs)} CPU, " +
                            $"{parent.LogicalReads:N0} logical reads.</p>");

                var primary = components.Where(x => x.IsPrimaryCause).ToList();
                if (primary.Count > 0)
                {
                    html.Append("<div class='card Critical'><h4>Primary cause</h4><ul>");
                    foreach (var component in primary)
                    {
                        html.Append($"<li><b>{HtmlUtility.Encode(component.ComponentName)}</b>: " +
                                    $"{HtmlUtility.Encode(component.Issue)} " +
                                    $"{HtmlUtility.Encode(component.Evidence)}</li>");
                    }
                    html.Append("</ul></div>");
                }
                else
                {
                    html.Append("<div class='card'><h4>Primary cause</h4>" +
                                "<p>No single component could be proven as the dominant cause. " +
                                "Review the component evidence below.</p></div>");
                }

                html.Append("<table><tr><th>Status</th><th>Component</th>" +
                            "<th>Exact SQL / location</th><th>Executions</th>" +
                            "<th>Elapsed / CPU</th><th>What is wrong</th>" +
                            "<th>Evidence</th><th>Fix</th></tr>");

                foreach (var component in components)
                {
                    var css = component.Status == "Critical" ? "Critical" :
                              component.Status == "High" ? "High" :
                              component.Status == "Review" ? "Medium" : "";

                    html.Append($"<tr class='{css}'>");
                    html.Append($"<td><b>{HtmlUtility.Encode(component.Status)}</b>" +
                                (component.IsPrimaryCause ? "<br>PRIMARY" : "") +
                                "</td>");
                    html.Append($"<td><b>{HtmlUtility.Encode(component.ComponentName)}</b><br>" +
                                $"{component.ComponentKind}<br>" +
                                (component.NodeId >= 0 ? $"Plan node {component.NodeId}" : "") +
                                "</td>");

                    html.Append("<td>");
                    html.Append(HtmlUtility.Encode(component.FixLocation));
                    if (!string.IsNullOrWhiteSpace(component.SqlText))
                    {
                        html.Append("<pre style='white-space:pre-wrap;max-width:700px;" +
                                    "background:#f7f9fc;border:1px solid #cbd5e1;" +
                                    "padding:10px;border-radius:5px;'>");
                        html.Append(HtmlUtility.Encode(component.SqlText));
                        html.Append("</pre>");
                    }
                    html.Append("</td>");

                    html.Append($"<td>{component.Executions:N0}</td>");

                    var elapsed = component.ElapsedMs > 0
                        ? FormatDuration(component.ElapsedMs)
                        : "Not independently isolated";
                    var cpu = component.CpuMs > 0
                        ? FormatDuration(component.CpuMs)
                        : "Not independently isolated";

                    html.Append($"<td><b>Elapsed:</b> {elapsed}<br>" +
                                $"<b>CPU:</b> {cpu}<br>" +
                                $"{HtmlUtility.Encode(component.TimingStatus)}</td>");
                    html.Append($"<td>{HtmlUtility.Encode(component.Issue)}</td>");
                    html.Append($"<td>{HtmlUtility.Encode(component.Evidence)}</td>");
                    html.Append($"<td>{HtmlUtility.Encode(component.RecommendedFix)}</td>");
                    html.Append("</tr>");
                }

                if (components.Count == 0)
                    html.Append("<tr><td colspan='8'>No component-level findings.</td></tr>");

                html.Append("</table></div>");
            }
        }

        private static void WriteSourceFocusedIssueLocations(
            StringBuilder html,
            AnalysisReport report)
        {
            html.Append("<h2>Exact SQL Location of Performance Problems</h2>");
            html.Append("<p class='muted'>The report highlights the smallest reliable " +
                        "SQL fragment responsible for each problem. When no smaller fragment " +
                        "can be mapped safely, the complete parent query is displayed.</p>");

            var groups = report.PlanIssues
                .GroupBy(x => x.StatementId)
                .OrderByDescending(x => x.Max(y => y.Priority))
                .ThenByDescending(x => x.Max(y => y.Severity))
                .ToList();

            foreach (var statementGroup in groups)
            {
                var statement = report.Statements.FirstOrDefault(x =>
                    x.StatementId == statementGroup.Key);

                html.Append("<div class='card'>");
                html.Append($"<h3>Statement {statementGroup.Key}</h3>");

                if (statement != null)
                {
                    html.Append($"<p><b>Statement elapsed:</b> " +
                                $"{FormatDuration(statement.ActualElapsedMs)} &nbsp; " +
                                $"<b>CPU:</b> {FormatDuration(statement.ActualCpuMs)} &nbsp; " +
                                $"<b>UDF elapsed:</b> {FormatDuration(statement.UdfElapsedMs)}</p>");
                }

                foreach (var issue in statementGroup
                    .OrderByDescending(x => x.Priority)
                    .ThenByDescending(x => x.Severity))
                {
                    var fragmentLabel = string.IsNullOrWhiteSpace(issue.FragmentDisplayName)
                        ? "Full SQL statement"
                        : issue.FragmentDisplayName;

                    html.Append($"<div class='card {issue.Severity}'>");
                    html.Append($"<h4>{issue.Severity} — " +
                                $"{HtmlUtility.Encode(issue.Issue)}</h4>");
                    html.Append($"<p><b>Problem location:</b> " +
                                $"{HtmlUtility.Encode(fragmentLabel)}");

                    if (issue.FragmentStartLine.HasValue)
                    {
                        html.Append($" — line {issue.FragmentStartLine}");
                        if (issue.FragmentEndLine.HasValue &&
                            issue.FragmentEndLine != issue.FragmentStartLine)
                        {
                            html.Append($" to {issue.FragmentEndLine}");
                        }
                    }

                    html.Append("</p>");

                    if (!string.IsNullOrWhiteSpace(issue.FragmentSqlText))
                    {
                        html.Append("<pre style='white-space:pre-wrap;background:#f7f9fc;" +
                                    "border:1px solid #cbd5e1;padding:12px;border-radius:6px;'>");
                        html.Append(HtmlUtility.Encode(issue.FragmentSqlText));
                        html.Append("</pre>");
                    }

                    html.Append($"<p><b>Why this fragment is identified:</b> " +
                                $"{HtmlUtility.Encode(issue.WhyItHappened)}</p>");
                    html.Append($"<p><b>Plan evidence:</b> " +
                                $"{HtmlUtility.Encode(issue.Evidence)}</p>");
                    html.Append($"<p><b>Impact:</b> " +
                                $"{HtmlUtility.Encode(issue.TimeOrCostImpact)}</p>");
                    html.Append($"<p><b>Fix:</b> " +
                                $"{HtmlUtility.Encode(issue.RecommendedFix)}</p>");
                    html.Append("</div>");
                }

                html.Append("</div>");
            }

            if (groups.Count == 0)
                html.Append("<p>No mapped plan issues were detected.</p>");
        }

        private static void WriteDetailedStatementFindings(
            StringBuilder html,
            AnalysisReport report)
        {
            var groups = report.PlanIssues
                .GroupBy(x => x.StatementId)
                .Select(g => new StatementIssueGroup
                {
                    StatementId = g.Key,
                    Statement = report.Statements.FirstOrDefault(x => x.StatementId == g.Key),
                    Issues = g.OrderByDescending(x => x.Priority)
                              .ThenByDescending(x => x.Severity)
                              .ThenBy(x => x.NodeId)
                              .ToList()
                })
                .OrderByDescending(x => x.HighestPriority)
                .ThenByDescending(x => x.HighestSeverity)
                .ThenBy(x => x.StatementId)
                .ToList();

            html.Append("<h2>Complete Developer and DBA Findings Grouped by Statement</h2>");
            html.Append("<p class='muted'>Each SQL statement appears once. " +
                        "Node IDs are retained inside the issue detail for DBA traceability.</p>");

            foreach (var group in groups)
            {
                var statement = group.Statement;
                html.Append("<div class='card'>");
                html.Append($"<h3>Statement {group.StatementId} – {group.HighestPriority} / {group.HighestSeverity}</h3>");
                html.Append($"<p><b>Procedure location:</b> " +
                            $"{(statement != null && statement.ProcedureStartLine.HasValue ? statement.ProcedureStartLine.ToString() : "Not mapped")}</p>");
                html.Append($"<p><b>Executions:</b> {(statement == null ? 0 : statement.ExecutionCount):N0}</p>");
                html.Append($"<p><b>Statement timing:</b> {HtmlUtility.Encode(StatementImpact(report, group))}</p>");
                html.Append($"<p><b>Consolidated issues:</b> {IssueBulletList(group.Issues)}</p>");
                html.Append($"<p><code>{HtmlUtility.Encode(statement == null ? string.Empty : statement.StatementText)}</code></p>");

                html.Append("<table><tr><th>Node</th><th>Priority</th><th>Severity</th>" +
                            "<th>Issue</th><th>SQL fragment</th><th>Why it happened</th><th>Fix location</th>" +
                            "<th>Recommended fix</th><th>Future risk</th><th>Evidence</th></tr>");

                foreach (var issue in group.Issues)
                {
                    html.Append($"<tr class='{issue.Severity}'>");
                    html.Append($"<td>{issue.NodeId}</td>");
                    html.Append($"<td class='{issue.Priority}'>{issue.Priority}</td>");
                    html.Append($"<td>{issue.Severity}</td>");
                    html.Append($"<td>{HtmlUtility.Encode(issue.Issue)}</td>");
                    html.Append($"<td><b>{HtmlUtility.Encode(issue.FragmentDisplayName)}</b><br>" +
                                $"Lines {issue.FragmentStartLine}-{issue.FragmentEndLine}<br>" +
                                $"<code>{HtmlUtility.Encode(issue.FragmentSqlText)}</code></td>");
                    html.Append($"<td>{HtmlUtility.Encode(issue.WhyItHappened)}</td>");
                    html.Append($"<td>{HtmlUtility.Encode(issue.FixLocation)}</td>");
                    html.Append($"<td>{HtmlUtility.Encode(issue.RecommendedFix)}</td>");
                    html.Append($"<td>{HtmlUtility.Encode(issue.FutureRisk)}</td>");
                    html.Append($"<td>{HtmlUtility.Encode(issue.Evidence)}</td></tr>");
                }

                html.Append("</table></div>");
            }

            if (groups.Count == 0)
                html.Append("<p>No configured execution-plan bottlenecks were detected.</p>");
        }

        private static void WriteStaticIssues(
            StringBuilder html,
            AnalysisReport report)
        {
            html.Append("<h2>Stored-Procedure Static Review</h2>");
            html.Append("<table><tr><th>Priority</th><th>Severity</th><th>Line</th>" +
                        "<th>Issue</th><th>Source</th><th>Fix location</th>" +
                        "<th>Fix</th><th>Future risk</th></tr>");

            foreach (var issue in report.StaticSqlIssues
                .OrderByDescending(x => x.Priority)
                .ThenByDescending(x => x.Severity))
            {
                html.Append($"<tr class='{issue.Severity}'><td>{issue.Priority}</td>" +
                            $"<td>{issue.Severity}</td><td>{issue.LineNumber}</td>" +
                            $"<td>{HtmlUtility.Encode(issue.Issue)}</td>" +
                            $"<td><code>{HtmlUtility.Encode(issue.SourceLine)}</code></td>" +
                            $"<td>{HtmlUtility.Encode(issue.FixLocation)}</td>" +
                            $"<td>{HtmlUtility.Encode(issue.RecommendedFix)}</td>" +
                            $"<td>{HtmlUtility.Encode(issue.FutureRisk)}</td></tr>");
            }

            if (string.IsNullOrWhiteSpace(report.ProcedureFile))
                html.Append("<tr><td colspan='8'>Not available: stored-procedure source was not supplied.</td></tr>");
            else if (report.StaticSqlIssues.Count == 0)
                html.Append("<tr><td colspan='8'>No configured static SQL issues were detected.</td></tr>");

            html.Append("</table>");
        }

        private static void WriteStatementSummary(
            StringBuilder html,
            AnalysisReport report)
        {
            html.Append("<h2>Query / Statement Timing</h2>");
            html.Append("<table><tr><th>Statement</th><th>Procedure line</th>" +
                        "<th>Executions</th><th>Elapsed time</th><th>CPU time</th><th>Logical reads</th>" +
                        "<th>Estimated cost</th><th>Issue count</th><th>Statement text</th></tr>");

            foreach (var statement in report.Statements)
            {
                var issueCount = report.PlanIssues.Count(x => x.StatementId == statement.StatementId);
                html.Append($"<tr><td>{statement.StatementId}</td>" +
                            $"<td>{statement.ProcedureStartLine}</td>" +
                            $"<td>{statement.ExecutionCount:N0}</td>" +
                            $"<td>{FormatDuration(statement.ActualElapsedMs)}</td>" +
                            $"<td>{FormatDuration(statement.ActualCpuMs)}</td>" +
                            $"<td>{statement.ActualLogicalReads:N0}</td>" +
                            $"<td>{statement.EstimatedSubtreeCost:N4}</td>" +
                            $"<td>{issueCount}</td>" +
                            $"<td><code>{HtmlUtility.Encode(statement.StatementText)}</code></td></tr>");
            }

            html.Append("</table>");
        }

        private static void WriteOperatorDetail(
            StringBuilder html,
            AnalysisReport report)
        {
            html.Append("<h2>DBA Operator Appendix</h2>");
            html.Append("<p class='muted'>Node-level rows are kept only in this technical appendix.</p>");
            html.Append("<table><tr><th>Stmt</th><th>Node</th><th>Operator</th>" +
                        "<th>Object / Index</th><th>Estimated rows</th><th>Actual rows</th>" +
                        "<th>Rows read</th><th>Executions</th><th>Elapsed ms</th>" +
                        "<th>CPU ms</th><th>Subtree cost</th></tr>");

            foreach (var op in report.Operators)
                html.Append($"<tr><td>{op.StatementId}</td><td>{op.NodeId}</td>" +
                            $"<td>{HtmlUtility.Encode(op.PhysicalOperation)}</td>" +
                            $"<td>{HtmlUtility.Encode(op.ObjectName)}<br>{HtmlUtility.Encode(op.IndexName)}</td>" +
                            $"<td>{op.EstimatedRows:N0}</td><td>{op.ActualRows:N0}</td>" +
                            $"<td>{op.ActualRowsRead:N0}</td><td>{op.ActualExecutions:N0}</td>" +
                            $"<td>{op.ActualElapsedMs:N1}</td><td>{op.ActualCpuMs:N1}</td>" +
                            $"<td>{op.EstimatedSubtreeCost:N4}</td></tr>");

            html.Append("</table>");
        }

        private static void WriteLimitations(
            StringBuilder html,
            AnalysisReport report)
        {
            html.Append("<div class='card'><h2>Interpretation and limitations</h2>");
            html.Append("<p>Actual elapsed time and CPU time are reported only when present in an actual execution plan. Estimated plans provide optimizer cost estimates, not measured time.</p>");
            html.Append("<p>Operator elapsed values can overlap because execution-plan operators form a pipeline; statement time is the preferred executive timing measure.</p>");
            html.Append("<p>Source-line mapping is best effort and requires the exact stored-procedure text corresponding to the plan.</p>");
            html.Append("<p>Index and code recommendations require developer and DBA validation against the full workload before production change.</p></div>");
        }

        private static string StatementImpact(
            AnalysisReport report,
            StatementIssueGroup group)
        {
            var statement = group.Statement;

            if (statement != null && report.PlanKind == PlanKind.Actual &&
                statement.ActualElapsedMs > 0)
            {
                return $"{statement.ExecutionCount:N0} execution(s); " +
                       $"{FormatDuration(statement.ActualElapsedMs)} elapsed, " +
                       $"{FormatDuration(statement.ActualCpuMs)} CPU, " +
                       $"{FormatDuration(statement.UdfElapsedMs)} UDF elapsed, " +
                       $"{FormatDuration(statement.UdfCpuMs)} UDF CPU and " +
                       $"{statement.ActualLogicalReads:N0} logical reads. " +
                       $"Source: {statement.TimingSource}.";
            }

            if (statement != null)
                return $"Actual time is unavailable. Statement estimated subtree cost: " +
                       $"{statement.EstimatedSubtreeCost:N4}.";

            return UniqueText(group.Issues.Select(x => x.TimeOrCostImpact));
        }


        private static string IssueBulletList(
            IEnumerable<ProcedureIssue> issues)
        {
            var groupedIssues = issues
                .GroupBy(x => new
                {
                    x.RuleId,
                    x.Issue,
                    x.Severity,
                    x.Priority
                })
                .Select(group => new
                {
                    group.Key.RuleId,
                    group.Key.Issue,
                    group.Key.Severity,
                    group.Key.Priority,
                    Count = group.Count(),
                    Nodes = group
                        .Select(x => x.NodeId)
                        .Distinct()
                        .OrderBy(x => x)
                        .ToList(),
                    Why = group
                        .Select(x => x.WhyItHappened)
                        .FirstOrDefault(x =>
                            !string.IsNullOrWhiteSpace(x))
                })
                .OrderByDescending(x => x.Priority)
                .ThenByDescending(x => x.Severity)
                .ToList();

            var html = new StringBuilder("<ul>");

            foreach (var issue in groupedIssues)
            {
                var occurrenceText = issue.Count == 1
                    ? "detected once"
                    : $"detected {issue.Count} times";

                var nodeText = issue.Nodes.Count == 0
                    ? string.Empty
                    : $"; affected plan nodes: " +
                      string.Join(", ", issue.Nodes);

                html.Append(
                    $"<li><b>{HtmlUtility.Encode(issue.Issue)}</b> " +
                    $"<span class='muted'>({occurrenceText}{nodeText})</span>");

                if (!string.IsNullOrWhiteSpace(issue.Why))
                {
                    html.Append(
                        $"<br>{HtmlUtility.Encode(issue.Why)}");
                }

                html.Append("</li>");
            }

            html.Append("</ul>");
            return html.ToString();
        }


        private static string ConsolidatedIssueSummary(
            IEnumerable<ProcedureIssue> issues)
        {
            var list = issues.ToList();
            var html = new StringBuilder("<ul>");

            foreach (var group in list
                .GroupBy(x => new { x.RuleId, x.Issue })
                .OrderByDescending(x => x.Max(y => y.Priority))
                .ThenByDescending(x => x.Max(y => y.Severity)))
            {
                var executions = group.Max(x =>
                    ExtractExecutions(x.Evidence));
                var nodes = string.Join(", ", group
                    .Select(x => x.NodeId)
                    .Distinct()
                    .OrderBy(x => x));

                html.Append($"<li><b>{HtmlUtility.Encode(group.Key.Issue)}</b>: " +
                            $"{group.Count()} plan occurrence(s), node(s) {nodes}");

                if (executions > 0)
                    html.Append($"; up to {executions:N0} execution(s)");

                html.Append(".</li>");
            }

            html.Append("</ul>");
            return html.ToString();
        }


        private static string ConsolidatedFixLocation(
            StatementIssueGroup group)
        {
            var statement = group.Statement;
            var baseLocation = statement != null &&
                               statement.ProcedureStartLine.HasValue
                ? $"Stored procedure lines {statement.ProcedureStartLine}" +
                  (statement.ProcedureEndLine.HasValue &&
                   statement.ProcedureEndLine != statement.ProcedureStartLine
                      ? $"-{statement.ProcedureEndLine}"
                      : string.Empty)
                : $"Statement {group.StatementId}";

            var objects = group.Issues
                .Select(x => ExtractObjectFromLocation(x.FixLocation))
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Distinct()
                .Take(6)
                .ToList();

            return objects.Count == 0
                ? baseLocation
                : $"{baseLocation}; review consolidated row-flow and predicates involving " +
                  $"{string.Join(", ", objects)}.";
        }

        private static string ExtractObjectFromLocation(
            string location)
        {
            if (string.IsNullOrWhiteSpace(location))
                return null;

            var match = System.Text.RegularExpressions.Regex.Match(
                location,
                @"object\s+([^,.;]+)",
                System.Text.RegularExpressions.RegexOptions.IgnoreCase);

            return match.Success ? match.Groups[1].Value.Trim() : null;
        }

        private static string ConsolidatedFix(
            IEnumerable<ProcedureIssue> issues)
        {
            var list = issues.ToList();
            var rules = new HashSet<string>(
                list.Select(x => x.RuleId));

            var steps = new List<string>();

            if (rules.Contains("EP011"))
                steps.Add("First reduce rows before the dominant function/operator and prevent repeated early evaluation.");

            if (rules.Contains("EP002"))
                steps.Add("Correct row-estimate causes: validate statistics, parameter sensitivity, skew and predicate selectivity.");

            if (rules.Contains("EP001"))
                steps.Add("Then re-test memory grant and remove sort/hash spills after row reduction.");

            if (rules.Contains("EP004"))
                steps.Add("Evaluate a covering access path only after the row-flow problem is corrected.");

            if (rules.Contains("EP003"))
                steps.Add("Align parameter and column data types to remove plan-affecting conversions.");

            if (rules.Contains("EP005"))
                steps.Add("Make predicates SARGable and reduce unnecessary rows read.");

            if (steps.Count == 0)
            {
                steps.AddRange(list
                    .Select(x => x.RecommendedFix)
                    .Where(x => !string.IsNullOrWhiteSpace(x))
                    .Distinct());
            }

            return string.Join(" ", steps);
        }

        private static int ExtractExecutions(
            string evidence)
        {
            if (string.IsNullOrWhiteSpace(evidence))
                return 0;

            var match = System.Text.RegularExpressions.Regex.Match(
                evidence,
                @"executions\s+([\d,]+)",
                System.Text.RegularExpressions.RegexOptions.IgnoreCase);

            if (!match.Success)
                return 0;

            int value;
            return int.TryParse(
                match.Groups[1].Value.Replace(",", string.Empty),
                out value)
                    ? value
                    : 0;
        }

        private static IEnumerable<string> ExtractFunctions(
            string evidence)
        {
            if (string.IsNullOrWhiteSpace(evidence))
                return Enumerable.Empty<string>();

            var match = System.Text.RegularExpressions.Regex.Match(
                evidence,
                @"functions\s+([^.;]+)",
                System.Text.RegularExpressions.RegexOptions.IgnoreCase);

            if (!match.Success)
                return Enumerable.Empty<string>();

            return match.Groups[1].Value
                .Split(new[] { ',' }, System.StringSplitOptions.RemoveEmptyEntries)
                .Select(x => x.Trim())
                .Where(x => !string.IsNullOrWhiteSpace(x));
        }

        private static string UniqueBulletList(
            IEnumerable<string> values)
        {
            var items = values
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Distinct()
                .ToList();

            if (items.Count == 0)
                return "—";

            var html = new StringBuilder("<ul>");
            foreach (var item in items)
                html.Append($"<li>{HtmlUtility.Encode(item)}</li>");
            html.Append("</ul>");
            return html.ToString();
        }

        private static string UniqueText(
            IEnumerable<string> values)
        {
            return string.Join(" ", values
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Distinct());
        }


        private static string FormatDuration(
            double milliseconds)
        {
            if (milliseconds <= 0)
                return "0 ms";

            if (milliseconds >= 1000)
                return $"{milliseconds / 1000.0:N2} sec ({milliseconds:N0} ms)";

            return $"{milliseconds:N1} ms";
        }

        private static string ShortText(
            string value,
            int maximum)
        {
            if (string.IsNullOrWhiteSpace(value))
                return string.Empty;

            return value.Length <= maximum
                ? value
                : value.Substring(0, maximum) + "…";
        }

        private static bool IsExecutiveIssue(
            ProcedureIssue issue)
        {
            return issue.Severity == Severity.Critical ||
                   issue.Severity == Severity.High ||
                   issue.Priority == RemediationPriority.FixNow;
        }

        private static bool IsExecutiveIssue(
            StaticSqlIssue issue)
        {
            return issue.Severity == Severity.Critical ||
                   issue.Severity == Severity.High ||
                   issue.Priority == RemediationPriority.FixNow;
        }

        private sealed class StatementIssueGroup
        {
            public int StatementId { get; set; }
            public StatementMetrics Statement { get; set; }
            public List<ProcedureIssue> Issues { get; set; }

            public RemediationPriority HighestPriority =>
                Issues.Max(x => x.Priority);

            public Severity HighestSeverity =>
                Issues.Max(x => x.Severity);
        }
    }
}
