namespace SqlAnalyzer.Core
{
    public sealed class StatementMetrics
    {
        public int StatementId { get; set; }
        public string StatementText { get; set; }
        public string StatementType { get; set; }
        public double EstimatedSubtreeCost { get; set; }
        public double ActualElapsedMs { get; set; }
        public double ActualCpuMs { get; set; }
        public long ActualLogicalReads { get; set; }
        public int ExecutionCount { get; set; }
        public double UdfElapsedMs { get; set; }
        public double UdfCpuMs { get; set; }
        public string TimingSource { get; set; }
        public int? ProcedureStartLine { get; set; }
        public int? ProcedureEndLine { get; set; }
        public string ProcedureLineStatus { get; set; }
    }
}
