using System;
using System.Collections.Generic;
using System.Linq;
namespace SqlAnalyzer.Core
{
    public sealed class AnalysisReport
    {
        public string ReportName { get; set; }
        public string PlanFile { get; set; }
        public string ProcedureFile { get; set; }
        public PlanKind PlanKind { get; set; }
        public DateTime GeneratedUtc { get; set; } = DateTime.UtcNow;
        public List<StatementMetrics> Statements { get; } = new List<StatementMetrics>();
        public List<OperatorMetrics> Operators { get; } = new List<OperatorMetrics>();
        public List<ProcedureIssue> PlanIssues { get; } = new List<ProcedureIssue>();
        public List<StaticSqlIssue> StaticSqlIssues { get; } = new List<StaticSqlIssue>();
        public List<SourceFragment> SourceFragments { get; } = new List<SourceFragment>();
        public List<StatementComponentFinding> ComponentFindings { get; } = new List<StatementComponentFinding>();
        public int Score { get { var all=PlanIssues.Select(x=>x.Severity).Concat(StaticSqlIssues.Select(x=>x.Severity)); var deduction=all.Sum(s=>s==Severity.Critical?25:s==Severity.High?15:s==Severity.Medium?7:s==Severity.Low?3:0); return Math.Max(0,100-deduction);} }
        public int FixNowCount => PlanIssues.Count(x=>x.Priority==RemediationPriority.FixNow)+StaticSqlIssues.Count(x=>x.Priority==RemediationPriority.FixNow);
        public int PlannedFixCount => PlanIssues.Count(x=>x.Priority==RemediationPriority.PlannedFix)+StaticSqlIssues.Count(x=>x.Priority==RemediationPriority.PlannedFix);
        public string ExecutiveDecision => FixNowCount>0?"Immediate remediation authorization is recommended before release.":PlannedFixCount>0?"Approve a remediation plan with a committed completion date.":"No immediate remediation is required; continue monitoring.";
    }
}
