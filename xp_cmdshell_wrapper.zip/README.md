# Registered xp_cmdshell Wrapper

This reference implementation launches approved Windows commands from SQL Server while registering an exact execution-to-process relationship. It is intended to replace direct `xp_cmdshell` calls for selected jobs and stored procedures.

The wrapper does **not** terminate processes. It provides the trusted execution registry required by the monitoring and termination design. Deploy and validate it in audit-only mode before connecting it to any termination helper.

## Components

- `sql/001_install.sql` creates the schema, profile table, execution registry, process evidence table, registration procedures, and `xt.usp_RunRegisteredCommand`.
- `windows/Invoke-RegisteredCommand.ps1` validates a command profile, starts the approved executable without invoking a shell, registers its PID and immutable process facts, emits heartbeats, waits for completion, and records the result.
- `windows/command-profiles.example.json` shows the profile format. Replace the examples with site-owned executables and arguments.
- `sql/010_example_usage.sql` shows calls from T-SQL and SQL Agent.
- `sql/020_module_signing_template.sql` shows how to grant only the wrapper module the server-level permissions needed for `xp_cmdshell` and request metadata.
- `tests/Wrapper.Tests.ps1` contains Pester tests for profile and argument validation.

## Security model

1. SQL callers receive `EXECUTE` on `xt.usp_RunRegisteredCommand`, not direct permission on `xp_cmdshell` or registry procedures. Module signing supplies the wrapper's server-level permissions.
2. The SQL procedure accepts a profile ID and a JSON array of arguments. It never concatenates a caller-supplied executable or raw command line.
3. The PowerShell launcher reads a protected local profile file and starts the executable through `System.Diagnostics.Process`, not `cmd.exe`, `Invoke-Expression`, or `Start-Process` command parsing.
4. Each profile contains an exact executable path, a maximum runtime, optional fixed arguments, per-position argument regular expressions, and allowed working-directory roots.
5. The launcher registers PID, parent PID, process creation time, executable path, owner SID, and a SHA-256 command hash before waiting for the process.
6. The registry update procedures require a one-time 256-bit registration secret. Only its SHA-256 hash is stored by SQL.
7. The launcher connects to SQL with Windows integrated authentication. Its Windows identity needs only `EXECUTE` on the three registry update procedures.

## Prerequisites

- SQL Server on Windows with `xp_cmdshell` already approved and enabled.
- Windows PowerShell 5.1 or later.
- A dedicated DBA database in which to install the `xt` schema.
- A protected installation directory such as `C:\ProgramData\SqlXpcmd`.
- The SQL Server service or SQL Agent proxy identity must be able to read the launcher and profile file.
- The launcher identity must be able to connect back to the SQL instance with integrated authentication.

## Installation

1. Review and run `sql/001_install.sql` in the DBA database.
2. Apply and review `sql/020_module_signing_template.sql`. Substitute protected certificate paths and a deployment secret; do not commit the secret.
3. Copy `Invoke-RegisteredCommand.ps1` and the approved profile JSON to `C:\ProgramData\SqlXpcmd`.
4. Set NTFS permissions:
   - Administrators and the deployment service: modify.
   - SQL Server service or the dedicated SQL Agent proxy: read and execute.
   - Other identities: no access.
5. Sign the PowerShell script with the organization's code-signing certificate and enforce `AllSigned` for the service identity.
6. Change `xt.ConfigInstance` to the correct launcher and profile paths.
7. Populate `xt.CommandProfile` with the same profile IDs and enabled state as the JSON file. SQL configuration is an early gate; the protected Windows file is authoritative for executable and argument validation.
8. Grant the SQL service identity `EXECUTE` on:
   - `xt.usp_RegisterProcess`
   - `xt.usp_HeartbeatExecution`
   - `xt.usp_CompleteExecution`
9. Grant approved job or procedure owners membership in `xt_command_executor`, or grant `EXECUTE` on `xt.usp_RunRegisteredCommand` to a narrower database role.
10. Execute a harmless test profile and confirm `xt.ExecutionRegistry` and `xt.ProcessEvidence` contain the expected PID and creation time.

## Configuration parity

The SQL and Windows profile stores deliberately overlap. A profile must be enabled in both places. SQL uses its table to reject unauthorized calls before invoking PowerShell. Windows uses its protected JSON file to prevent a compromised or incorrectly configured SQL caller from selecting arbitrary executables.

## Calling contract

```sql
DECLARE @ExecutionId uniqueidentifier;

EXEC xt.usp_RunRegisteredCommand
    @ProfileId = N'ExampleEcho',
    @ArgumentsJson = N'["hello-from-sql"]',
    @WorkingDirectory = NULL,
    @ExecutionId = @ExecutionId OUTPUT;

SELECT @ExecutionId AS ExecutionId;
```

The call remains synchronous, like native `xp_cmdshell`. The launcher exits with the child process exit code where it fits the process exit-code range. SQL records the lifecycle even when the caller is disconnected.

## Operational queries

```sql
SELECT TOP (100)
    e.ExecutionId, e.SessionId, e.ProfileId, e.State,
    e.RequestedUtc, e.StartedUtc, e.LastHeartbeatUtc, e.CompletedUtc,
    p.ProcessId, p.ParentProcessId, p.CreationTimeUtc, p.ImagePath,
    e.ExitCode, e.ErrorNumber, e.ErrorMessage
FROM xt.ExecutionRegistry AS e
LEFT JOIN xt.ProcessEvidence AS p ON p.ExecutionId = e.ExecutionId
ORDER BY e.RequestedUtc DESC;
```

## Production hardening checklist

- Replace all example profiles.
- Use only dedicated tools or scripts; do not profile `cmd.exe`, `powershell.exe`, `pwsh.exe`, `wscript.exe`, `cscript.exe`, or another general-purpose interpreter.
- Sign the launcher and any script executable referenced by a profile.
- Reapply the SQL module signature after every alteration of `xt.usp_RunRegisteredCommand`; deployment verification should fail when the signature is missing.
- Restrict and audit changes to both profile stores.
- Set a command-specific maximum runtime.
- Keep argument patterns anchored with `^` and `$` and as narrow as practical.
- Forward registry lifecycle failures to centralized monitoring.
- Validate concurrent executions, SQL restart behavior, launcher identity, PID reuse protection, and secret redaction in preproduction.
- Do not enable automatic termination until the broader design's audit-only acceptance gates are met.
